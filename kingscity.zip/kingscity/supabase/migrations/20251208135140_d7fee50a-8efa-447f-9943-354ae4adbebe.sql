-- Insert the 8 properties from the website
INSERT INTO properties (title, location, price, bedrooms, bathrooms, area_sqft, is_available, is_featured, description) VALUES
('Modern Luxury Villa', 'East Legon, Accra', 500000, 4, 4, 3500, true, true, 'A stunning modern luxury villa in the heart of East Legon'),
('Contemporary Estate Home', 'Airport Residential, Accra', 750000, 5, 5, 4800, true, true, 'Elegant contemporary estate home in the prestigious Airport Residential area'),
('Executive Townhouse', 'Spintex, Accra', 350000, 4, 3, 2800, true, false, 'Beautiful executive townhouse in the vibrant Spintex area'),
('Luxury Duplex with Pool', 'Tema Community 25', 450000, 5, 4, 3900, true, true, 'Luxurious duplex featuring a private pool in Tema Community 25'),
('Premium Apartment Complex', 'Cantonments, Accra', 2500, 3, 3, 2200, true, false, 'Premium apartment available for rent in Cantonments'),
('Modern Residential Estate', 'Oyarifa, Accra', 400000, 5, 5, 4200, true, false, 'Spacious modern residential estate in Oyarifa'),
('Contemporary Villa Estate', 'Haatso, Accra', 380000, 4, 4, 3600, true, false, 'Contemporary villa estate with modern amenities in Haatso'),
('Elegant Modern Residence', 'Trasacco Valley, Accra', 850000, 5, 5, 5100, true, true, 'Elegant modern residence in the exclusive Trasacco Valley');

-- Insert the 8 services from the website
INSERT INTO services (name) VALUES
('General Construction'),
('Real Estate Agency Service'),
('Property/Asset Management'),
('Project Management & Supervision'),
('Cleaning & Waste Management'),
('Real Estate Development'),
('Land/Quantity Surveying'),
('Architectural & Landscape Designs');