-- Create workers table for team management
CREATE TABLE public.workers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name VARCHAR NOT NULL,
  position VARCHAR NOT NULL,
  bio TEXT,
  email VARCHAR,
  phone VARCHAR,
  photo_url TEXT,
  display_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.workers ENABLE ROW LEVEL SECURITY;

-- Allow public read access for active workers
CREATE POLICY "Allow public read access on active workers"
ON public.workers
FOR SELECT
USING (is_active = true);

-- Allow admins to manage workers
CREATE POLICY "Admins can manage workers"
ON public.workers
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));