-- Enable RLS on property_services table
ALTER TABLE property_services ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read access on property_services" 
ON property_services FOR SELECT 
USING (true);

CREATE POLICY "Allow all operations on property_services" 
ON property_services FOR ALL 
USING (true) WITH CHECK (true);