-- Add category column to workers table
ALTER TABLE workers ADD COLUMN category TEXT DEFAULT 'team';

-- Create index for better performance
CREATE INDEX idx_workers_category ON workers(category);

-- Add constraint to ensure only valid values
ALTER TABLE workers ADD CONSTRAINT check_workers_category 
CHECK (category IN ('board', 'team'));
