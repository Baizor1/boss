-- Create service_images table similar to property_images
CREATE TABLE public.service_images (
  id UUID NOT NULL DEFAULT extensions.uuid_generate_v4() PRIMARY KEY,
  service_id UUID REFERENCES public.services(id) ON DELETE CASCADE,
  image_url TEXT NOT NULL,
  is_primary BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.service_images ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow public read access on service_images" 
ON public.service_images 
FOR SELECT 
USING (true);

CREATE POLICY "Allow all operations on service_images" 
ON public.service_images 
FOR ALL 
USING (true) 
WITH CHECK (true);