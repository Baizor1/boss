import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/hooks/useAuth";
import ScrollToTop from "@/components/ScrollToTop";
import FloatingWhatsApp from "@/components/FloatingWhatsApp";
import Index from "./pages/Index";
import About from "./pages/About";
import Services from "./pages/Services";
import Properties from "./pages/Properties";
import PropertyDetail from "./pages/PropertyDetail";
import Contact from "./pages/Contact";
import NotFound from "./pages/NotFound";
import GeneralConstruction from "./pages/services/GeneralConstruction";
import RealEstateAgency from "./pages/services/RealEstateAgency";
import PropertyManagement from "./pages/services/PropertyManagement";
import ProjectManagement from "./pages/services/ProjectManagement";
import CleaningWasteManagement from "./pages/services/CleaningWasteManagement";
import LandSurveying from "./pages/services/LandSurveying";
import RealEstateDevelopment from "./pages/services/RealEstateDevelopment";
import ArchitecturalDesign from "./pages/services/ArchitecturalDesign";
import Admin from "./pages/Admin";
import Auth from "./pages/Auth";
import Affiliates from "./pages/Affiliates";
import Management from "./pages/Management";
import WorkerDetail from "./pages/WorkerDetail";
import BoardOfDirectors from "./pages/BoardOfDirectors";
import ManagementTeam from "./pages/ManagementTeam";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <ScrollToTop />
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/properties" element={<Properties />} />
            <Route path="/properties/:id" element={<PropertyDetail />} />
            <Route path="/about" element={<About />} />
            <Route path="/services" element={<Services />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/services/general-construction" element={<GeneralConstruction />} />
            <Route path="/services/real-estate-agency" element={<RealEstateAgency />} />
            <Route path="/services/property-management" element={<PropertyManagement />} />
            <Route path="/services/project-management" element={<ProjectManagement />} />
            <Route path="/services/cleaning-waste-management" element={<CleaningWasteManagement />} />
            <Route path="/services/land-surveying" element={<LandSurveying />} />
            <Route path="/services/real-estate-development" element={<RealEstateDevelopment />} />
            <Route path="/services/architectural-design" element={<ArchitecturalDesign />} />
            <Route path="/affiliates" element={<Affiliates />} />
            <Route path="/management" element={<Management />} />
            <Route path="/management/board" element={<BoardOfDirectors />} />
            <Route path="/management/team" element={<ManagementTeam />} />
            <Route path="/management/:id" element={<WorkerDetail />} />
            <Route path="/admin" element={<Admin />} />
            <Route path="/auth" element={<Auth />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
          <FloatingWhatsApp />
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
