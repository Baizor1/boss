import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mail, Phone, ArrowLeft, Users, Calendar, MapPin } from "lucide-react";

type Worker = {
  id: string;
  name: string;
  position: string;
  bio: string | null;
  email: string | null;
  phone: string | null;
  photo_url: string | null;
  display_order: number | null;
  is_active: boolean | null;
  category?: string;
  created_at: string | null;
};

const WorkerProfile = () => {
  const { id } = useParams<{ id: string }>();
  const [worker, setWorker] = useState<Worker | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      fetchWorker(id);
    }
  }, [id]);

  const fetchWorker = async (workerId: string) => {
    const { data, error } = await supabase
      .from("workers" as any)
      .select("*")
      .eq("id", workerId)
      .single();

    if (!error && data) {
      setWorker(data as unknown as Worker);
    }
    setLoading(false);
  };

  if (loading) {
    return (
      <>
        <Header />
        <div className="min-h-screen flex items-center justify-center">
          <div className="animate-pulse">Loading profile...</div>
        </div>
        <Footer />
      </>
    );
  }

  if (!worker) {
    return (
      <>
        <Header />
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <Users className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-2xl font-semibold mb-2">Profile Not Found</h2>
            <p className="text-muted-foreground mb-4">The requested profile could not be found.</p>
            <Link to="/management">
              <Button>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Management
              </Button>
            </Link>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Header />

      <main className="min-h-screen">
        {/* Hero Section */}
        <section className="bg-primary text-primary-foreground py-16">
          <div className="container">
            <Link to="/management" className="inline-flex items-center text-primary-foreground/80 hover:text-primary-foreground mb-6 transition-colors">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Management
            </Link>
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <div className="mb-6">
                  <span className="inline-block px-3 py-1 bg-primary-foreground/20 text-primary-foreground rounded-full text-sm mb-4">
                    {worker.category === 'board' ? 'Board of Directors' : 'Management Team'}
                  </span>
                  <h1 className="text-4xl font-bold mb-4">{worker.name}</h1>
                  <p className="text-xl opacity-90">{worker.position}</p>
                </div>
              </div>
              <div className="flex justify-center md:justify-end">
                {worker.photo_url ? (
                  <img
                    src={worker.photo_url}
                    alt={worker.name}
                    className="w-64 h-64 object-cover rounded-full border-4 border-primary-foreground/20"
                  />
                ) : (
                  <div className="w-64 h-64 bg-primary-foreground/20 rounded-full flex items-center justify-center">
                    <Users className="h-32 w-32 text-primary-foreground/60" />
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* Profile Details */}
        <section className="py-16">
          <div className="container">
            <div className="grid md:grid-cols-3 gap-8">
              {/* Main Content */}
              <div className="md:col-span-2">
                <Card className="mb-8">
                  <CardContent className="p-8">
                    <h2 className="text-2xl font-bold mb-4">About</h2>
                    {worker.bio ? (
                      <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">
                        {worker.bio}
                      </p>
                    ) : (
                      <p className="text-muted-foreground italic">
                        No biography available for this team member.
                      </p>
                    )}
                  </CardContent>
                </Card>

                {/* Contact Information */}
                <Card>
                  <CardContent className="p-8">
                    <h2 className="text-2xl font-bold mb-6">Contact Information</h2>
                    <div className="grid md:grid-cols-2 gap-6">
                      {worker.email && (
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                            <Mail className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Email</p>
                            <a
                              href={`mailto:${worker.email}`}
                              className="font-medium hover:text-primary transition-colors"
                            >
                              {worker.email}
                            </a>
                          </div>
                        </div>
                      )}
                      {worker.phone && (
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                            <Phone className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <p className="text-sm text-muted-foreground">Phone</p>
                            <a
                              href={`tel:${worker.phone}`}
                              className="font-medium hover:text-primary transition-colors"
                            >
                              {worker.phone}
                            </a>
                          </div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Sidebar */}
              <div>
                <Card className="sticky top-4">
                  <CardContent className="p-6">
                    <h3 className="font-semibold mb-4">Quick Actions</h3>
                    <div className="space-y-3">
                      {worker.email && (
                        <Button variant="outline" className="w-full" asChild>
                          <a href={`mailto:${worker.email}`}>
                            <Mail className="h-4 w-4 mr-2" />
                            Send Email
                          </a>
                        </Button>
                      )}
                      {worker.phone && (
                        <Button variant="outline" className="w-full" asChild>
                          <a href={`tel:${worker.phone}`}>
                            <Phone className="h-4 w-4 mr-2" />
                            Call Now
                          </a>
                        </Button>
                      )}
                      <Button variant="outline" className="w-full" asChild>
                        <Link to="/management">
                          <ArrowLeft className="h-4 w-4 mr-2" />
                          Back to Team
                        </Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Additional Info */}
                {worker.created_at && (
                  <Card className="mt-6">
                    <CardContent className="p-6">
                      <h3 className="font-semibold mb-4">Additional Information</h3>
                      <div className="space-y-3 text-sm">
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          <span className="text-muted-foreground">Joined:</span>
                          <span>{new Date(worker.created_at).toLocaleDateString()}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-muted-foreground" />
                          <span className="text-muted-foreground">Location:</span>
                          <span>Ghana</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default WorkerProfile;
