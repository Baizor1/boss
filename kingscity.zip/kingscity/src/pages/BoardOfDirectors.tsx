import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";
import { Mail, Phone, ArrowRight, Users, Building2, ArrowLeft } from "lucide-react";

type Worker = {
  id: string;
  name: string;
  position: string;
  bio: string | null;
  email: string | null;
  phone: string | null;
  photo_url: string | null;
  display_order: number | null;
  is_active: boolean | null;
  category?: string;
};

const BoardOfDirectors = () => {
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchWorkers();
  }, []);

  const fetchWorkers = async () => {
    const { data, error } = await supabase
      .from("workers" as any)
      .select("*")
      .eq("is_active", true)
      .eq("category", "board")
      .order("display_order", { ascending: true });

    if (!error && data) {
      setWorkers(data as unknown as Worker[]);
    }
    setLoading(false);
  };

  // Worker Card Component
  const WorkerCard = ({ worker }: { worker: Worker }) => (
    <Link to={`/management/${worker.id}`} className="block">
      <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 group cursor-pointer transform hover:scale-105">
        <div className="aspect-square bg-muted relative overflow-hidden">
          {worker.photo_url ? (
            <img
              src={worker.photo_url}
              alt={worker.name}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Users className="h-20 w-20 text-muted-foreground" />
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          <div className="absolute bottom-0 left-0 right-0 p-4 text-white transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
            <p className="text-sm font-medium">View Full Profile</p>
          </div>
        </div>
        <CardContent className="p-4">
          <h3 className="font-semibold text-lg group-hover:text-primary transition-colors">{worker.name}</h3>
          <p className="text-accent font-medium text-sm mb-3">{worker.position}</p>
          
          {worker.bio && (
            <p className="text-muted-foreground text-sm line-clamp-2 mb-3">
              {worker.bio}
            </p>
          )}

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {worker.email && (
                <a
                  href={`mailto:${worker.email}`}
                  className="text-muted-foreground hover:text-primary transition-colors"
                  title={worker.email}
                  onClick={(e) => e.stopPropagation()}
                >
                  <Mail className="h-4 w-4" />
                </a>
              )}
              {worker.phone && (
                <a
                  href={`tel:${worker.phone}`}
                  className="text-muted-foreground hover:text-primary transition-colors"
                  title={worker.phone}
                  onClick={(e) => e.stopPropagation()}
                >
                  <Phone className="h-4 w-4" />
                </a>
              )}
            </div>
            <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
          </div>
        </CardContent>
      </Card>
    </Link>
  );

  return (
    <>
      <Header />

      <main className="min-h-screen">
        {/* Hero Section */}
        <section className="bg-primary text-primary-foreground py-16">
          <div className="container">
            <Link to="/management" className="inline-flex items-center text-primary-foreground/80 hover:text-primary-foreground mb-6 transition-colors">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Management
            </Link>
            <div className="text-center">
              <Building2 className="h-16 w-16 mx-auto mb-4 opacity-80" />
              <h1 className="text-4xl font-bold mb-4">Board of Directors</h1>
              <p className="text-lg opacity-90 max-w-2xl mx-auto">
                Our distinguished board members provide strategic guidance and governance to ensure the success and integrity of Kings City Estates.
              </p>
            </div>
          </div>
        </section>

        {/* Board Members Grid */}
        <section className="py-16">
          <div className="container">
            {loading ? (
              <div className="text-center py-12">
                <div className="animate-pulse">Loading board members...</div>
              </div>
            ) : workers.length === 0 ? (
              <div className="text-center py-12">
                <Building2 className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold mb-2">Board members will be featured here</h3>
                <p className="text-muted-foreground">Check back soon to meet our distinguished board members.</p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {workers.map((worker) => (
                  <WorkerCard key={worker.id} worker={worker} />
                ))}
              </div>
            )}
          </div>
        </section>
      </main>

      <Footer />
    </>
  );
};

export default BoardOfDirectors;
