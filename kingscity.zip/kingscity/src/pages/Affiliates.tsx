import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink, Building2, Loader2 } from "lucide-react";

type Affiliate = {
  id: string;
  name: string;
  description: string | null;
  logo_url: string | null;
  website_url: string | null;
  category: string | null;
  display_order: number | null;
};

const Affiliates = () => {
  const [affiliates, setAffiliates] = useState<Affiliate[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAffiliates();
  }, []);

  const fetchAffiliates = async () => {
    const { data, error } = await supabase
      .from("affiliates")
      .select("*")
      .eq("is_active", true)
      .order("display_order", { ascending: true });

    if (!error && data) {
      setAffiliates(data);
    }
    setLoading(false);
  };

  const partners = affiliates.filter(a => a.category === "partner");
  const companies = affiliates.filter(a => a.category !== "partner");

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-primary text-primary-foreground py-16">
          <div className="container text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Partners & Affiliates</h1>
            <p className="text-lg text-primary-foreground/80 max-w-2xl mx-auto">
              We work with trusted partners and companies to deliver exceptional real estate services across Ghana.
            </p>
          </div>
        </section>

        {loading ? (
          <div className="flex justify-center items-center py-20">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : (
          <>
            {/* Partners Section */}
            {partners.length > 0 && (
              <section className="py-16">
                <div className="container">
                  <h2 className="text-3xl font-bold text-center mb-10">Our Partners</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {partners.map((affiliate) => (
                      <Card key={affiliate.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                        <CardContent className="p-6">
                          <div className="flex items-center gap-4 mb-4">
                            {affiliate.logo_url ? (
                              <img
                                src={affiliate.logo_url}
                                alt={affiliate.name}
                                className="w-16 h-16 object-contain rounded-lg bg-muted p-2"
                              />
                            ) : (
                              <div className="w-16 h-16 bg-muted rounded-lg flex items-center justify-center">
                                <Building2 className="h-8 w-8 text-muted-foreground" />
                              </div>
                            )}
                            <div>
                              <h3 className="font-semibold text-lg">{affiliate.name}</h3>
                              <span className="text-xs text-muted-foreground uppercase tracking-wide">Partner</span>
                            </div>
                          </div>
                          {affiliate.description && (
                            <p className="text-muted-foreground text-sm mb-4">{affiliate.description}</p>
                          )}
                          {affiliate.website_url && (
                            <Button variant="outline" size="sm" asChild>
                              <a href={affiliate.website_url} target="_blank" rel="noopener noreferrer">
                                <ExternalLink className="h-4 w-4 mr-2" /> Visit Website
                              </a>
                            </Button>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </section>
            )}

            {/* Other Companies Section */}
            {companies.length > 0 && (
              <section className="py-16 bg-muted/30">
                <div className="container">
                  <h2 className="text-3xl font-bold text-center mb-10">Associated Companies</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {companies.map((affiliate) => (
                      <Card key={affiliate.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                        <CardContent className="p-6">
                          <div className="flex items-center gap-4 mb-4">
                            {affiliate.logo_url ? (
                              <img
                                src={affiliate.logo_url}
                                alt={affiliate.name}
                                className="w-16 h-16 object-contain rounded-lg bg-muted p-2"
                              />
                            ) : (
                              <div className="w-16 h-16 bg-muted rounded-lg flex items-center justify-center">
                                <Building2 className="h-8 w-8 text-muted-foreground" />
                              </div>
                            )}
                            <div>
                              <h3 className="font-semibold text-lg">{affiliate.name}</h3>
                              <span className="text-xs text-muted-foreground uppercase tracking-wide">
                                {affiliate.category || "Company"}
                              </span>
                            </div>
                          </div>
                          {affiliate.description && (
                            <p className="text-muted-foreground text-sm mb-4">{affiliate.description}</p>
                          )}
                          {affiliate.website_url && (
                            <Button variant="outline" size="sm" asChild>
                              <a href={affiliate.website_url} target="_blank" rel="noopener noreferrer">
                                <ExternalLink className="h-4 w-4 mr-2" /> Visit Website
                              </a>
                            </Button>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </section>
            )}

            {/* Empty State */}
            {affiliates.length === 0 && (
              <section className="py-20 text-center">
                <Building2 className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                <h2 className="text-2xl font-semibold mb-2">Coming Soon</h2>
                <p className="text-muted-foreground">
                  Our partner and affiliate information will be available shortly.
                </p>
              </section>
            )}
          </>
        )}
      </main>

      <Footer />
    </div>
  );
};

export default Affiliates;
