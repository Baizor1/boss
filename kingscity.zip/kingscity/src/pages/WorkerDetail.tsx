import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Mail, Phone, Users } from "lucide-react";

type Worker = {
  id: string;
  name: string;
  position: string;
  bio: string | null;
  email: string | null;
  phone: string | null;
  photo_url: string | null;
  display_order: number | null;
  is_active: boolean | null;
};

const WorkerDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [worker, setWorker] = useState<Worker | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      fetchWorker();
    }
  }, [id]);

  const fetchWorker = async () => {
    const { data, error } = await supabase
      .from("workers" as any)
      .select("*")
      .eq("id", id)
      .eq("is_active", true)
      .single();

    if (!error && data) {
      setWorker(data as unknown as Worker);
    }
    setLoading(false);
  };

  if (loading) {
    return (
      <>
        <Header />
        <div className="min-h-screen flex items-center justify-center">
          <div className="animate-pulse">Loading...</div>
        </div>
        <Footer />
      </>
    );
  }

  if (!worker) {
    return (
      <>
        <Header />
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <Users className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-2xl font-bold mb-2">Worker Not Found</h2>
            <p className="text-muted-foreground mb-4">This team member doesn't exist or is no longer active.</p>
            <Link to="/management">
              <Button>
                <ArrowLeft className="h-4 w-4 mr-2" /> Back to Team
              </Button>
            </Link>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Header />

      <main className="min-h-screen py-12">
        <div className="container">
          <Link to="/management">
            <Button variant="ghost" className="mb-6">
              <ArrowLeft className="h-4 w-4 mr-2" /> Back to Team
            </Button>
          </Link>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Photo */}
            <div className="md:col-span-1">
              <Card className="overflow-hidden">
                <div className="aspect-square bg-muted">
                  {worker.photo_url ? (
                    <img
                      src={worker.photo_url}
                      alt={worker.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Users className="h-24 w-24 text-muted-foreground" />
                    </div>
                  )}
                </div>
              </Card>
            </div>

            {/* Details */}
            <div className="md:col-span-2">
              <h1 className="text-3xl font-bold mb-2">{worker.name}</h1>
              <p className="text-xl text-accent font-medium mb-6">{worker.position}</p>

              {worker.bio && (
                <Card className="mb-6">
                  <CardContent className="p-6">
                    <h2 className="text-lg font-semibold mb-3">About</h2>
                    <p className="text-muted-foreground whitespace-pre-line">{worker.bio}</p>
                  </CardContent>
                </Card>
              )}

              {/* Contact Information */}
              {(worker.email || worker.phone) && (
                <Card>
                  <CardContent className="p-6">
                    <h2 className="text-lg font-semibold mb-4">Contact Information</h2>
                    <div className="space-y-3">
                      {worker.email && (
                        <a
                          href={`mailto:${worker.email}`}
                          className="flex items-center gap-3 text-muted-foreground hover:text-primary transition-colors"
                        >
                          <Mail className="h-5 w-5" />
                          <span>{worker.email}</span>
                        </a>
                      )}
                      {worker.phone && (
                        <a
                          href={`tel:${worker.phone}`}
                          className="flex items-center gap-3 text-muted-foreground hover:text-primary transition-colors"
                        >
                          <Phone className="h-5 w-5" />
                          <span>{worker.phone}</span>
                        </a>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </>
  );
};

export default WorkerDetail;
