import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ContactSection from "@/components/ContactSection";
import { useServiceImages } from "@/hooks/useServiceImages";
import { Skeleton } from "@/components/ui/skeleton";

// Fallback images
import property7 from "@/assets/property-7.jpg";
import property8 from "@/assets/property-8.jpg";
import property9 from "@/assets/property-9.jpg";
import property10 from "@/assets/property-10.jpg";
import livingRoomGreen1 from "@/assets/living-room-green-1.jpg";
import livingRoomGreen2 from "@/assets/living-room-green-2.jpg";

const fallbackImages = [
  property7,
  property8,
  property9,
  property10,
  livingRoomGreen1,
  livingRoomGreen2,
];

const RealEstateAgency = () => {
  const { data: dbImages, isLoading } = useServiceImages("Real Estate Agency Service");
  
  const images = dbImages && dbImages.length > 0 
    ? dbImages.map(img => img.image_url) 
    : fallbackImages;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="relative h-[60vh] overflow-hidden">
          <img
            src={images[0] || property7}
            alt="Real Estate Agency Services"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/30" />
          <div className="absolute inset-0 flex items-center">
            <div className="container">
              <h1 className="text-5xl md:text-7xl font-bold text-white mb-4">
                Real Estate Agency Services
              </h1>
              <p className="text-xl text-white/90 max-w-2xl">
                Professional real estate solutions
              </p>
            </div>
          </div>
        </section>

        {/* Content Section */}
        <section className="py-20">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
              <div>
                <h2 className="text-3xl font-bold mb-6">Your Trusted Real Estate Partner</h2>
                <p className="text-muted-foreground mb-4">
                  We offer comprehensive real estate agency services to help you buy, sell, or rent properties with confidence.
                </p>
                <ul className="space-y-3 text-muted-foreground">
                  <li>• Property sales and acquisitions</li>
                  <li>• Rental management</li>
                  <li>• Property valuations</li>
                  <li>• Market analysis</li>
                  <li>• Legal assistance</li>
                </ul>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {isLoading ? (
                  <>
                    <Skeleton className="w-full h-64 rounded-lg" />
                    <Skeleton className="w-full h-64 rounded-lg" />
                  </>
                ) : (
                  <>
                    <img
                      src={images[1] || property8}
                      alt="Property listing"
                      className="rounded-lg w-full h-64 object-cover"
                    />
                    <img
                      src={images[2] || property9}
                      alt="Real estate services"
                      className="rounded-lg w-full h-64 object-cover"
                    />
                  </>
                )}
              </div>
            </div>
            
            <div className="grid md:grid-cols-4 gap-6">
              {isLoading ? (
                Array(4).fill(0).map((_, i) => (
                  <Skeleton key={i} className="w-full h-64 rounded-lg" />
                ))
              ) : (
                images.slice(3, 7).map((img, index) => (
                  <img
                    key={index}
                    src={img}
                    alt={`Property ${index + 1}`}
                    className="rounded-lg w-full h-64 object-cover"
                  />
                ))
              )}
            </div>
          </div>
        </section>

        <ContactSection />
      </main>
      <Footer />
    </div>
  );
};

export default RealEstateAgency;