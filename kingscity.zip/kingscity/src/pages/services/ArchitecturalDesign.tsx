import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ContactSection from "@/components/ContactSection";
import { useServiceImages } from "@/hooks/useServiceImages";
import { Skeleton } from "@/components/ui/skeleton";

// Fallback images
import serviceInterior1 from "@/assets/service-interior-1.jpg";
import serviceInterior2 from "@/assets/service-interior-2.jpg";
import serviceInterior3 from "@/assets/service-interior-3.jpg";
import interiorStaircase1 from "@/assets/interior-staircase-1.jpg";
import interiorCloset1 from "@/assets/interior-closet-1.jpg";
import bathroomModern1 from "@/assets/bathroom-modern-1.jpg";

const fallbackImages = [
  serviceInterior1,
  serviceInterior2,
  serviceInterior3,
  interiorStaircase1,
  interiorCloset1,
  bathroomModern1,
];

const ArchitecturalDesign = () => {
  const { data: dbImages, isLoading } = useServiceImages("Architectural & Landscape Designs");
  
  const images = dbImages && dbImages.length > 0 
    ? dbImages.map(img => img.image_url) 
    : fallbackImages;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="relative h-[60vh] overflow-hidden">
          <img
            src={images[0] || serviceInterior1}
            alt="Architectural Design"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/30" />
          <div className="absolute inset-0 flex items-center">
            <div className="container">
              <h1 className="text-5xl md:text-7xl font-bold text-white mb-4">
                Architectural, Interior & Landscape Designs
              </h1>
              <p className="text-xl text-white/90 max-w-2xl">
                Creative design solutions for your space
              </p>
            </div>
          </div>
        </section>

        {/* Content Section */}
        <section className="py-20">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
              <div>
                <h2 className="text-3xl font-bold mb-6">Comprehensive Design Services</h2>
                <p className="text-muted-foreground mb-4">
                  We offer complete architectural, interior, and landscape design services to transform your vision into reality.
                </p>
                <ul className="space-y-3 text-muted-foreground">
                  <li>• Architectural planning and design</li>
                  <li>• Interior design solutions</li>
                  <li>• Bathroom and kitchen design</li>
                  <li>• Custom closet and storage design</li>
                  <li>• Landscape design</li>
                  <li>• 3D visualization</li>
                </ul>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {isLoading ? (
                  <>
                    <Skeleton className="w-full h-64 rounded-lg" />
                    <Skeleton className="w-full h-64 rounded-lg" />
                  </>
                ) : (
                  <>
                    <img
                      src={images[1] || serviceInterior2}
                      alt="Interior design"
                      className="rounded-lg w-full h-64 object-cover"
                    />
                    <img
                      src={images[2] || serviceInterior3}
                      alt="Interior design solutions"
                      className="rounded-lg w-full h-64 object-cover"
                    />
                  </>
                )}
              </div>
            </div>

            <div className="grid md:grid-cols-4 gap-6">
              {isLoading ? (
                Array(4).fill(0).map((_, i) => (
                  <Skeleton key={i} className="w-full h-64 rounded-lg" />
                ))
              ) : (
                images.slice(3, 7).map((img, index) => (
                  <img
                    key={index}
                    src={img}
                    alt={`Design ${index + 1}`}
                    className="rounded-lg w-full h-64 object-cover"
                  />
                ))
              )}
            </div>
          </div>
        </section>

        <ContactSection />
      </main>
      <Footer />
    </div>
  );
};

export default ArchitecturalDesign;