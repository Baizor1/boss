import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PropertiesSection from "@/components/PropertiesSection";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Home, Key } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";
import { useState } from "react";

const Properties = () => {
  const navigate = useNavigate();
  const [clickedButton, setClickedButton] = useState<string | null>(null);
  const [showProperties, setShowProperties] = useState(false);

  // Fetch property counts for each type
  const { data: propertyCounts, isLoading: countsLoading } = useQuery({
    queryKey: ["property-counts"],
    queryFn: async () => {
      const { data: rentalData, error: rentalError } = await supabase
        .from("properties")
        .select("id")
        .eq("property_type", "rent")
        .eq("is_available", true);

      const { data: saleData, error: saleError } = await supabase
        .from("properties")
        .select("id")
        .eq("property_type", "sale")
        .eq("is_available", true);

      if (rentalError) throw rentalError;
      if (saleError) throw saleError;

      return {
        rental: rentalData?.length || 0,
        sale: saleData?.length || 0,
        total: (rentalData?.length || 0) + (saleData?.length || 0)
      };
    },
  });

  const handlePropertyTypeClick = (type: string) => {
    setClickedButton(type);
    setShowProperties(true);
    navigate(`/properties?type=${type}`);

    // Reset clicked state after animation
    setTimeout(() => setClickedButton(null), 300);
  };

  const handleBackToButtons = () => {
    setShowProperties(false);
    navigate('/properties');
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-16">
        <div className="bg-gradient-to-br from-secondary/30 via-background to-secondary/20 py-16">
          <div className="container">
            <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">
              Our Properties
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl">
              Browse our exclusive collection of premium properties across Ghana. From luxury villas to modern apartments, find your perfect space.
            </p>
          </div>
        </div>

        {/* Property Type Cards - Only shown when properties are not visible */}
        {!showProperties && (
          <div className="animate-in fade-in duration-500">
            <div className="container py-12">
              <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
                {/* Rental Properties Card */}
                <Card 
                  className={`group cursor-pointer transition-all duration-300 hover:shadow-xl hover:scale-105 bg-gray-50 border-gray-200 ${
                    clickedButton === 'rent' ? 'scale-95 shadow-inner' : ''
                  }`}
                  onClick={() => handlePropertyTypeClick('rent')}
                >
                  <CardContent className="p-8">
                    <div className="flex justify-between items-start mb-6">
                      <div className="p-3 bg-gray-200 rounded-lg">
                        <Key className="h-8 w-8 text-gray-600" />
                      </div>
                      <div className="text-right">
                        <div className="text-3xl font-bold text-primary">
                          {countsLoading ? <Skeleton className="w-12 h-8 mx-auto" /> : propertyCounts?.rental || 0}
                        </div>
                        <div className="text-sm text-muted-foreground">Properties</div>
                      </div>
                    </div>
                    <h3 className="text-xl font-semibold text-primary mb-3">Rental Properties</h3>
                    <p className="text-muted-foreground mb-6">
                      Find your perfect rental space with flexible terms and competitive pricing
                    </p>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-muted-foreground">
                        {countsLoading ? (
                          <Skeleton className="w-20 h-4" />
                        ) : (
                          `${propertyCounts?.rental || 0} Available Units`
                        )}
                      </span>
                      <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                    </div>
                  </CardContent>
                </Card>

                {/* For Sale Properties Card */}
                <Card 
                  className={`group cursor-pointer transition-all duration-300 hover:shadow-xl hover:scale-105 bg-yellow-50 border-yellow-200 ${
                    clickedButton === 'sale' ? 'scale-95 shadow-inner' : ''
                  }`}
                  onClick={() => handlePropertyTypeClick('sale')}
                >
                  <CardContent className="p-8">
                    <div className="flex justify-between items-start mb-6">
                      <div className="p-3 bg-yellow-200 rounded-lg">
                        <Home className="h-8 w-8 text-yellow-700" />
                      </div>
                      <div className="text-right">
                        <div className="text-3xl font-bold text-primary">
                          {countsLoading ? <Skeleton className="w-12 h-8 mx-auto" /> : propertyCounts?.sale || 0}
                        </div>
                        <div className="text-sm text-muted-foreground">Properties</div>
                      </div>
                    </div>
                    <h3 className="text-xl font-semibold text-primary mb-3">For Sale Properties</h3>
                    <p className="text-muted-foreground mb-6">
                      Own your dream home with our premium selection of properties for sale
                    </p>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-muted-foreground">
                        {countsLoading ? (
                          <Skeleton className="w-20 h-4" />
                        ) : (
                          `${propertyCounts?.sale || 0} Available Units`
                        )}
                      </span>
                      <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        )}

        {/* PropertiesSection - Only shown when a button is clicked */}
        {showProperties && (
          <div className="animate-in fade-in slide-in-from-top-4 duration-500">
            <div className="container py-8">
              <button
                onClick={handleBackToButtons}
                className="flex items-center text-muted-foreground hover:text-primary transition-colors mb-6"
              >
                <ArrowRight className="h-4 w-4 mr-2 rotate-180" />
                Back to Property Types
              </button>
            </div>
            <PropertiesSection />
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
};

export default Properties;
