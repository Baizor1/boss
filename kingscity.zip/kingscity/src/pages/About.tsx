import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Building2, Target, Eye, Heart } from "lucide-react";

const About = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="relative py-20 bg-gradient-to-br from-primary/10 via-background to-accent/10">
          <div className="container">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold text-primary mb-6">
                Who We Are
              </h1>
              <p className="text-xl text-muted-foreground mb-4">
                New life companion: YOUR COMFORT, HEALTH AND WEALTH OUR PRIORITY
              </p>
              <p className="text-lg text-muted-foreground">
                Proudly creating places to work, live, connect and enjoy
              </p>
            </div>
          </div>
        </section>

        {/* Mission Section */}
        <section className="py-16 bg-card">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <div className="flex items-center gap-3 mb-6">
                  <Target className="h-10 w-10 text-accent" />
                  <h2 className="text-3xl font-bold text-primary">Our Mission</h2>
                </div>
                <p className="text-lg text-muted-foreground">
                  To be the leading commercial real estate development and management services provider on a global scale.
                </p>
              </div>
              <div>
                <div className="flex items-center gap-3 mb-6">
                  <Eye className="h-10 w-10 text-accent" />
                  <h2 className="text-3xl font-bold text-primary">Our Vision</h2>
                </div>
                <ul className="space-y-4 text-muted-foreground">
                  <li className="flex gap-2">
                    <span className="text-accent mt-1">•</span>
                    <span>To offer the highest level of commercial real estate, development and management services through thoughtful, cooperative, and ethical practices.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-accent mt-1">•</span>
                    <span>To deliver extensive market knowledge, skilled analysis and sound real estate advice to every client, while building lifelong relationships.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-accent mt-1">•</span>
                    <span>To utilize innovative technologies that support better life and business, partnering with those who thrive in an environment built on trust and collaboration.</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Company Description */}
        <section className="py-16">
          <div className="container">
            <div className="max-w-4xl mx-auto">
              <div className="flex items-center gap-3 mb-6 justify-center">
                <Building2 className="h-10 w-10 text-accent" />
                <h2 className="text-3xl font-bold text-primary">Full Management Services</h2>
              </div>
              <p className="text-lg text-center text-muted-foreground mb-8">
                We shape cities, reimagine communities, and create comfort places for everyone.
              </p>
              <p className="text-muted-foreground mb-6">
                We provide comprehensive acquisition, leasing, disposition, exchange, designs, build and management consulting to full brokerage services.
              </p>
              <p className="text-muted-foreground">
                Kings City estates is meticulously designed with the highest level of detail oriented engineers, architects, designers, environmental and health professionals including the most dedicated and experienced team of builders to ensure that each home is built with quality materials and components that are designed to last and give comfort.
              </p>
            </div>
          </div>
        </section>

        {/* Guiding Principles */}
        <section className="py-16 bg-muted/30">
          <div className="container">
            <div className="flex items-center gap-3 mb-12 justify-center">
              <Heart className="h-10 w-10 text-accent" />
              <h2 className="text-3xl font-bold text-primary">Our Guiding Principles</h2>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
              {[
                {
                  title: "Accountability",
                  description: "We are all accountable for our actions."
                },
                {
                  title: "Collaboration",
                  description: "We promote a true collaborative environment that fosters good will, a cooperative spirit, and strong alliances."
                },
                {
                  title: "Excellence",
                  description: "We strive to go above and beyond in everything we do."
                },
                {
                  title: "Integrity",
                  description: "We embody the characteristics of being honest and having strong moral principles."
                },
                {
                  title: "Discipline",
                  description: "We are dedicated to providing the highest level of service to the very best of our abilities."
                },
                {
                  title: "Ethical",
                  description: "We believe in showing the characteristics of sound virtues."
                },
                {
                  title: "Passion",
                  description: "We exude energy, enthusiasm, and excitement in all our endeavors."
                },
                {
                  title: "Community Outreach",
                  description: "We are committed to giving back by volunteering and improving the communities we operate."
                }
              ].map((principle, index) => (
                <div key={index} className="bg-card p-6 rounded-lg border hover:border-accent transition-colors">
                  <h3 className="text-xl font-semibold text-primary mb-3">{principle.title}</h3>
                  <p className="text-sm text-muted-foreground">{principle.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Expertise Section */}
        <section className="py-16">
          <div className="container">
            <h2 className="text-3xl font-bold text-primary mb-8 text-center">Our Specialized Areas</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 max-w-4xl mx-auto">
              {[
                "Multi-Family",
                "Residential",
                "Vacation Homes",
                "Retail/Offices",
                "Industrial",
                "Infrastructure",
                "Lands",
                "Hospitality",
                "Public Parks",
                "Religious Centers",
                "Recreational Centers"
              ].map((area, index) => (
                <div key={index} className="bg-card p-4 rounded-lg border text-center hover:border-accent transition-colors">
                  <span className="text-muted-foreground font-medium">{area}</span>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default About;
