import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/hooks/use-toast";
import { Pencil, Trash2, Plus, LogOut, Upload, X, Image as ImageIcon, ShieldX, Loader2, Users, Shield, ShieldCheck, Building2, UserCircle, Home, Key } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { Tables } from "@/integrations/supabase/types";

type Property = Tables<"properties">;
type Service = Tables<"services">;
type PropertyImage = Tables<"property_images">;
type ServiceImage = { id: string; service_id: string | null; image_url: string; is_primary: boolean | null; created_at: string | null };
type UserWithRoles = {
  id: string;
  email: string;
  created_at: string;
  last_sign_in_at: string | null;
  roles: string[];
};
type Affiliate = {
  id: string;
  name: string;
  description: string | null;
  logo_url: string | null;
  website_url: string | null;
  category: string | null;
  is_active: boolean | null;
  display_order: number | null;
  created_at: string | null;
  updated_at: string | null;
};
type Worker = {
  id: string;
  name: string;
  position: string;
  bio: string | null;
  email: string | null;
  phone: string | null;
  photo_url: string | null;
  display_order: number | null;
  is_active: boolean | null;
  created_at: string | null;
  updated_at: string | null;
};

const PROTECTED_ADMIN_EMAIL = "kingscityestate@gmail.com";

const Admin = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading, isAdmin, signOut } = useAuth();

  const [properties, setProperties] = useState<Property[]>([]);
  const [services, setServices] = useState<Service[]>([]);
  const [users, setUsers] = useState<UserWithRoles[]>([]);
  const [affiliates, setAffiliates] = useState<Affiliate[]>([]);
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [propertyImages, setPropertyImages] = useState<Record<string, PropertyImage[]>>({});
  const [serviceImages, setServiceImages] = useState<Record<string, ServiceImage[]>>({});
  const [loading, setLoading] = useState(false);
  const [usersLoading, setUsersLoading] = useState(false);
  const [affiliatesLoading, setAffiliatesLoading] = useState(false);
  const [workersLoading, setWorkersLoading] = useState(false);
  const [editingProperty, setEditingProperty] = useState<Property | null>(null);
  const [editingService, setEditingService] = useState<Service | null>(null);
  const [editingAffiliate, setEditingAffiliate] = useState<Affiliate | null>(null);
  const [editingWorker, setEditingWorker] = useState<Worker | null>(null);
  const [propertyDialogOpen, setPropertyDialogOpen] = useState(false);
  const [serviceDialogOpen, setServiceDialogOpen] = useState(false);
  const [userDialogOpen, setUserDialogOpen] = useState(false);
  const [affiliateDialogOpen, setAffiliateDialogOpen] = useState(false);
  const [workerDialogOpen, setWorkerDialogOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [creatingUser, setCreatingUser] = useState(false);

  const [newUserForm, setNewUserForm] = useState({
    email: "",
    password: "",
    makeAdmin: false,
  });

  const propertyImageRef = useRef<HTMLInputElement>(null);
  const serviceImageRef = useRef<HTMLInputElement>(null);

  const [propertyForm, setPropertyForm] = useState({
    title: "",
    location: "",
    price: "",
    description: "",
    bedrooms: "",
    bathrooms: "",
    area_sqft: "",
    acres: "",
    property_type: "sale",
    is_available: true,
    is_featured: false,
  });

  const [propertyImageFiles, setPropertyImageFiles] = useState<File[]>([]);
  const [propertyImagePreviews, setPropertyImagePreviews] = useState<string[]>([]);
  const [existingPropertyImages, setExistingPropertyImages] = useState<PropertyImage[]>([]);

  const [serviceForm, setServiceForm] = useState({
    name: "",
    image_url: "",
  });

  const [serviceImageFiles, setServiceImageFiles] = useState<File[]>([]);
  const [serviceImagePreviews, setServiceImagePreviews] = useState<string[]>([]);
  const [existingServiceImages, setExistingServiceImages] = useState<ServiceImage[]>([]);

  const [affiliateForm, setAffiliateForm] = useState({
    name: "",
    description: "",
    logo_url: "",
    website_url: "",
    category: "partner",
    is_active: true,
    display_order: "0",
  });

  const affiliateLogoRef = useRef<HTMLInputElement>(null);
  const [affiliateLogoFile, setAffiliateLogoFile] = useState<File | null>(null);
  const [affiliateLogoPreview, setAffiliateLogoPreview] = useState<string | null>(null);

  const [workerForm, setWorkerForm] = useState({
    name: "",
    position: "",
    bio: "",
    email: "",
    phone: "",
    photo_url: "",
    is_active: true,
    display_order: "0",
    category: "team", // 'board' or 'team'
  });

  const workerPhotoRef = useRef<HTMLInputElement>(null);
  const [workerPhotoFile, setWorkerPhotoFile] = useState<File | null>(null);
  const [workerPhotoPreview, setWorkerPhotoPreview] = useState<string | null>(null);

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/auth");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (user && isAdmin) {
      fetchProperties();
      fetchServices();
      fetchUsers();
      fetchAffiliates();
      fetchWorkers();
    }
  }, [user, isAdmin]);

  const handleLogout = async () => {
    await signOut();
    navigate("/auth");
  };

  const fetchProperties = async () => {
    setLoading(true);
    const { data, error } = await supabase.from("properties").select("*").order("created_at", { ascending: false });
    if (error) {
      toast({ title: "Error fetching properties", description: error.message, variant: "destructive" });
    } else {
      setProperties(data || []);
      const imagesMap: Record<string, PropertyImage[]> = {};
      for (const property of data || []) {
        const { data: images } = await supabase
          .from("property_images")
          .select("*")
          .eq("property_id", property.id);
        imagesMap[property.id] = images || [];
      }
      setPropertyImages(imagesMap);
    }
    setLoading(false);
  };

  const fetchServices = async () => {
    const { data, error } = await supabase.from("services").select("*").order("created_at", { ascending: false });
    if (error) {
      toast({ title: "Error fetching services", description: error.message, variant: "destructive" });
    } else {
      setServices(data || []);
      const imagesMap: Record<string, ServiceImage[]> = {};
      for (const service of data || []) {
        const { data: images } = await supabase
          .from("service_images")
          .select("*")
          .eq("service_id", service.id);
        imagesMap[service.id] = (images as ServiceImage[]) || [];
      }
      setServiceImages(imagesMap);
    }
  };

  const fetchAffiliates = async () => {
    setAffiliatesLoading(true);
    const { data, error } = await supabase.from("affiliates").select("*").order("display_order", { ascending: true });
    if (error) {
      toast({ title: "Error fetching affiliates", description: error.message, variant: "destructive" });
    } else {
      setAffiliates(data || []);
    }
    setAffiliatesLoading(false);
  };

  const fetchWorkers = async () => {
    setWorkersLoading(true);
    const { data, error } = await supabase.from("workers" as any).select("*").order("display_order", { ascending: true });
    if (error) {
      toast({ title: "Error fetching workers", description: error.message, variant: "destructive" });
    } else {
      setWorkers((data as unknown as Worker[]) || []);
    }
    setWorkersLoading(false);
  };

  const fetchUsers = async () => {
    setUsersLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast({ title: "Not authenticated", variant: "destructive" });
        return;
      }

      const response = await fetch(
        `https://flqdjuhizlvsgbxrbvyi.supabase.co/functions/v1/admin-users?action=list`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
            'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZscWRqdWhpemx2c2dieHJidnlpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjUxOTAxMjUsImV4cCI6MjA4MDc2NjEyNX0.ZieY2rcGY2_LLx5WoHFRIuIf2lIjsXFV0w7EvimdZ8Q'
          }
        }
      );
      const data = await response.json();

      if (!response.ok || data?.error) {
        console.error('Function error:', data?.error);
        toast({ title: "Error fetching users", description: data?.error || 'Failed to fetch users', variant: "destructive" });
        return;
      }

      setUsers(data?.users || []);
    } catch (error: any) {
      console.error('Error fetching users:', error);
      toast({ title: "Error fetching users", description: error.message, variant: "destructive" });
    } finally {
      setUsersLoading(false);
    }
  };

  const addAdminRole = async (userId: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const response = await fetch(
        `https://flqdjuhizlvsgbxrbvyi.supabase.co/functions/v1/admin-users?action=add-role`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
            'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZscWRqdWhpemx2c2dieHJidnlpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjUxOTAxMjUsImV4cCI6MjA4MDc2NjEyNX0.ZieY2rcGY2_LLx5WoHFRIuIf2lIjsXFV0w7EvimdZ8Q'
          },
          body: JSON.stringify({ userId, role: 'admin' })
        }
      );
      const data = await response.json();

      if (!response.ok || data?.error) {
        toast({ title: "Error adding admin role", description: data?.error || 'Failed to add role', variant: "destructive" });
        return;
      }

      toast({ title: "Admin role added successfully" });
      fetchUsers();
    } catch (error: any) {
      toast({ title: "Error adding admin role", description: error.message, variant: "destructive" });
    }
  };

  const removeAdminRole = async (userId: string) => {
    if (!confirm("Are you sure you want to remove admin role from this user?")) return;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const response = await fetch(
        `https://flqdjuhizlvsgbxrbvyi.supabase.co/functions/v1/admin-users?action=remove-role`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
            'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZscWRqdWhpemx2c2dieHJidnlpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjUxOTAxMjUsImV4cCI6MjA4MDc2NjEyNX0.ZieY2rcGY2_LLx5WoHFRIuIf2lIjsXFV0w7EvimdZ8Q'
          },
          body: JSON.stringify({ userId, role: 'admin' })
        }
      );
      const data = await response.json();

      if (!response.ok || data?.error) {
        toast({ title: "Error removing admin role", description: data?.error || 'Failed to remove role', variant: "destructive" });
        return;
      }

      toast({ title: "Admin role removed successfully" });
      fetchUsers();
    } catch (error: any) {
      toast({ title: "Error removing admin role", description: error.message, variant: "destructive" });
    }
  };

  const createUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreatingUser(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const response = await fetch(
        `https://flqdjuhizlvsgbxrbvyi.supabase.co/functions/v1/admin-users?action=create-user`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
            'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZscWRqdWhpemx2c2dieHJidnlpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjUxOTAxMjUsImV4cCI6MjA4MDc2NjEyNX0.ZieY2rcGY2_LLx5WoHFRIuIf2lIjsXFV0w7EvimdZ8Q'
          },
          body: JSON.stringify({
            email: newUserForm.email,
            password: newUserForm.password,
            makeAdmin: newUserForm.makeAdmin
          })
        }
      );
      const data = await response.json();

      if (!response.ok || data?.error) {
        toast({ title: "Error creating user", description: data?.error || 'Failed to create user', variant: "destructive" });
        return;
      }

      toast({ title: "User created successfully" });
      setUserDialogOpen(false);
      setNewUserForm({ email: "", password: "", makeAdmin: false });
      fetchUsers();
    } catch (error: any) {
      toast({ title: "Error creating user", description: error.message, variant: "destructive" });
    } finally {
      setCreatingUser(false);
    }
  };

  const uploadImage = async (file: File, folder: string): Promise<string | null> => {
    const fileExt = file.name.split('.').pop();
    const fileName = `${folder}/${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;

    const { error } = await supabase.storage
      .from('property-images')
      .upload(fileName, file);

    if (error) {
      console.error('Upload error:', error);
      return null;
    }

    const { data } = supabase.storage
      .from('property-images')
      .getPublicUrl(fileName);

    return data.publicUrl;
  };

  const resetPropertyForm = () => {
    setPropertyForm({
      title: "",
      location: "",
      price: "",
      description: "",
      bedrooms: "",
      bathrooms: "",
      area_sqft: "",
      acres: "",
      property_type: "sale",
      is_available: true,
      is_featured: false,
    });
    setEditingProperty(null);
    setPropertyImageFiles([]);
    setPropertyImagePreviews([]);
    setExistingPropertyImages([]);
  };

  const resetServiceForm = () => {
    setServiceForm({ name: "", image_url: "" });
    setEditingService(null);
    setServiceImageFiles([]);
    setServiceImagePreviews([]);
    setExistingServiceImages([]);
  };

  const openPropertyEdit = async (property: Property) => {
    setEditingProperty(property);
    setPropertyForm({
      title: property.title,
      location: property.location,
      price: property.price.toString(),
      description: property.description || "",
      bedrooms: property.bedrooms?.toString() || "",
      bathrooms: property.bathrooms?.toString() || "",
      area_sqft: property.area_sqft?.toString() || "",
      acres: property.acres?.toString() || "",
      property_type: property.property_type || "sale",
      is_available: property.is_available ?? true,
      is_featured: property.is_featured ?? false,
    });

    const { data: images } = await supabase
      .from("property_images")
      .select("*")
      .eq("property_id", property.id);
    setExistingPropertyImages(images || []);
    setPropertyImageFiles([]);
    setPropertyImagePreviews([]);
    setPropertyDialogOpen(true);
  };

  const openServiceEdit = async (service: Service) => {
    setEditingService(service);
    setServiceForm({
      name: service.name,
      image_url: service.image_url || "",
    });

    const { data: images } = await supabase
      .from("service_images")
      .select("*")
      .eq("service_id", service.id);
    setExistingServiceImages((images as ServiceImage[]) || []);
    setServiceImageFiles([]);
    setServiceImagePreviews([]);
    setServiceDialogOpen(true);
  };

  const handlePropertyImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setPropertyImageFiles(prev => [...prev, ...files]);

    files.forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPropertyImagePreviews(prev => [...prev, reader.result as string]);
      };
      reader.readAsDataURL(file);
    });
  };

  const removePropertyImagePreview = (index: number) => {
    setPropertyImageFiles(prev => prev.filter((_, i) => i !== index));
    setPropertyImagePreviews(prev => prev.filter((_, i) => i !== index));
  };

  const removeExistingPropertyImage = async (imageId: string) => {
    const { error } = await supabase.from("property_images").delete().eq("id", imageId);
    if (error) {
      toast({ title: "Error removing image", variant: "destructive" });
    } else {
      setExistingPropertyImages(prev => prev.filter(img => img.id !== imageId));
    }
  };

  const handleServiceImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setServiceImageFiles(prev => [...prev, ...files]);

    files.forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setServiceImagePreviews(prev => [...prev, reader.result as string]);
      };
      reader.readAsDataURL(file);
    });
  };

  const removeServiceImagePreview = (index: number) => {
    setServiceImageFiles(prev => prev.filter((_, i) => i !== index));
    setServiceImagePreviews(prev => prev.filter((_, i) => i !== index));
  };

  const removeExistingServiceImage = async (imageId: string) => {
    const { error } = await supabase.from("service_images").delete().eq("id", imageId);
    if (error) {
      toast({ title: "Error removing image", variant: "destructive" });
    } else {
      setExistingServiceImages(prev => prev.filter(img => img.id !== imageId));
    }
  };

  const handlePropertySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setUploading(true);

    try {
      const propertyData = {
        title: propertyForm.title,
        location: propertyForm.location,
        price: parseFloat(propertyForm.price),
        description: propertyForm.description || null,
        bedrooms: propertyForm.bedrooms ? parseInt(propertyForm.bedrooms) : null,
        bathrooms: propertyForm.bathrooms ? parseInt(propertyForm.bathrooms) : null,
        area_sqft: propertyForm.area_sqft ? parseInt(propertyForm.area_sqft) : null,
        acres: propertyForm.acres ? parseFloat(propertyForm.acres) : null,
        property_type: propertyForm.property_type,
        is_available: propertyForm.is_available,
        is_featured: propertyForm.is_featured,
      };

      let propertyId = editingProperty?.id;

      if (editingProperty) {
        const { error } = await supabase.from("properties").update(propertyData).eq("id", editingProperty.id);
        if (error) throw error;
      } else {
        const { data, error } = await supabase.from("properties").insert(propertyData).select().single();
        if (error) throw error;
        propertyId = data.id;
      }

      for (let i = 0; i < propertyImageFiles.length; i++) {
        const imageUrl = await uploadImage(propertyImageFiles[i], 'properties');
        if (imageUrl) {
          await supabase.from("property_images").insert({
            property_id: propertyId,
            image_url: imageUrl,
            is_primary: i === 0 && existingPropertyImages.length === 0,
          });
        }
      }

      toast({ title: editingProperty ? "Property updated successfully" : "Property added successfully" });
      fetchProperties();
      setPropertyDialogOpen(false);
      resetPropertyForm();
    } catch (error: any) {
      toast({ title: "Error saving property", description: error.message, variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const handleServiceSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setUploading(true);

    try {
      const serviceData = {
        name: serviceForm.name,
        image_url: serviceForm.image_url || null,
      };

      let serviceId = editingService?.id;

      if (editingService) {
        const { error } = await supabase.from("services").update(serviceData).eq("id", editingService.id);
        if (error) throw error;
      } else {
        const { data, error } = await supabase.from("services").insert(serviceData).select().single();
        if (error) throw error;
        serviceId = data.id;
      }

      // Upload new service images
      for (let i = 0; i < serviceImageFiles.length; i++) {
        const imageUrl = await uploadImage(serviceImageFiles[i], 'services');
        if (imageUrl) {
          await supabase.from("service_images").insert({
            service_id: serviceId,
            image_url: imageUrl,
            is_primary: i === 0 && existingServiceImages.length === 0,
          });
        }
      }

      toast({ title: editingService ? "Service updated successfully" : "Service added successfully" });
      fetchServices();
      setServiceDialogOpen(false);
      resetServiceForm();
    } catch (error: any) {
      toast({ title: "Error saving service", description: error.message, variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const deleteProperty = async (id: string) => {
    if (!confirm("Are you sure you want to delete this property?")) return;

    await supabase.from("property_images").delete().eq("property_id", id);

    const { error } = await supabase.from("properties").delete().eq("id", id);
    if (error) {
      toast({ title: "Error deleting property", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Property deleted" });
      fetchProperties();
    }
  };

  const deleteService = async (id: string) => {
    if (!confirm("Are you sure you want to delete this service?")) return;

    // Delete service images first (cascade should handle this but being explicit)
    await supabase.from("service_images").delete().eq("service_id", id);

    const { error } = await supabase.from("services").delete().eq("id", id);
    if (error) {
      toast({ title: "Error deleting service", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Service deleted" });
      fetchServices();
    }
  };

  // Affiliate functions
  const resetAffiliateForm = () => {
    setAffiliateForm({
      name: "",
      description: "",
      logo_url: "",
      website_url: "",
      category: "partner",
      is_active: true,
      display_order: "0",
    });
    setEditingAffiliate(null);
    setAffiliateLogoFile(null);
    setAffiliateLogoPreview(null);
  };

  const openAffiliateEdit = (affiliate: Affiliate) => {
    setEditingAffiliate(affiliate);
    setAffiliateForm({
      name: affiliate.name,
      description: affiliate.description || "",
      logo_url: affiliate.logo_url || "",
      website_url: affiliate.website_url || "",
      category: affiliate.category || "partner",
      is_active: affiliate.is_active ?? true,
      display_order: affiliate.display_order?.toString() || "0",
    });
    setAffiliateLogoFile(null);
    setAffiliateLogoPreview(null);
    setAffiliateDialogOpen(true);
  };

  const handleAffiliateLogoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setAffiliateLogoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setAffiliateLogoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAffiliateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setUploading(true);

    try {
      let logoUrl = affiliateForm.logo_url;

      if (affiliateLogoFile) {
        const uploadedUrl = await uploadImage(affiliateLogoFile, 'affiliates');
        if (uploadedUrl) {
          logoUrl = uploadedUrl;
        }
      }

      const affiliateData = {
        name: affiliateForm.name,
        description: affiliateForm.description || null,
        logo_url: logoUrl || null,
        website_url: affiliateForm.website_url || null,
        category: affiliateForm.category,
        is_active: affiliateForm.is_active,
        display_order: parseInt(affiliateForm.display_order) || 0,
      };

      if (editingAffiliate) {
        const { error } = await supabase.from("affiliates").update(affiliateData).eq("id", editingAffiliate.id);
        if (error) throw error;
        toast({ title: "Affiliate updated successfully" });
      } else {
        const { error } = await supabase.from("affiliates").insert(affiliateData);
        if (error) throw error;
        toast({ title: "Affiliate added successfully" });
      }

      fetchAffiliates();
      setAffiliateDialogOpen(false);
      resetAffiliateForm();
    } catch (error: any) {
      toast({ title: "Error saving affiliate", description: error.message, variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const deleteAffiliate = async (id: string) => {
    if (!confirm("Are you sure you want to delete this affiliate?")) return;

    const { error } = await supabase.from("affiliates").delete().eq("id", id);
    if (error) {
      toast({ title: "Error deleting affiliate", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Affiliate deleted" });
      fetchAffiliates();
    }
  };

  // Worker functions
  const resetWorkerForm = () => {
    setWorkerForm({
      name: "",
      position: "",
      bio: "",
      email: "",
      phone: "",
      photo_url: "",
      is_active: true,
      display_order: "0",
      category: "team",
    });
    setEditingWorker(null);
    setWorkerPhotoFile(null);
    setWorkerPhotoPreview(null);
  };

  const openWorkerEdit = (worker: Worker) => {
    setEditingWorker(worker);
    setWorkerForm({
      name: worker.name,
      position: worker.position,
      bio: worker.bio || "",
      email: worker.email || "",
      phone: worker.phone || "",
      photo_url: worker.photo_url || "",
      is_active: worker.is_active ?? true,
      display_order: worker.display_order?.toString() || "0",
      category: (worker as any).category || "team",
    });
    setWorkerPhotoFile(null);
    setWorkerPhotoPreview(null);
    setWorkerDialogOpen(true);
  };

  const handleWorkerPhotoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setWorkerPhotoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setWorkerPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleWorkerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setUploading(true);

    try {
      let photoUrl = workerForm.photo_url;

      if (workerPhotoFile) {
        const uploadedUrl = await uploadImage(workerPhotoFile, 'workers');
        if (uploadedUrl) {
          photoUrl = uploadedUrl;
        }
      }

      const workerData = {
        name: workerForm.name,
        position: workerForm.position,
        bio: workerForm.bio || null,
        email: workerForm.email || null,
        phone: workerForm.phone || null,
        photo_url: photoUrl || null,
        is_active: workerForm.is_active,
        display_order: parseInt(workerForm.display_order) || 0,
        category: workerForm.category,
      };

      if (editingWorker) {
        const { error } = await supabase.from("workers" as any).update(workerData).eq("id", editingWorker.id);
        if (error) throw error;
        toast({ title: "Worker updated successfully" });
      } else {
        const { error } = await supabase.from("workers" as any).insert(workerData);
        if (error) throw error;
        toast({ title: "Worker added successfully" });
      }

      fetchWorkers();
      setWorkerDialogOpen(false);
      resetWorkerForm();
    } catch (error: any) {
      toast({ title: "Error saving worker", description: error.message, variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const deleteWorker = async (id: string) => {
    if (!confirm("Are you sure you want to delete this worker?")) return;

    const { error } = await supabase.from("workers" as any).delete().eq("id", id);
    if (error) {
      toast({ title: "Error deleting worker", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Worker deleted" });
      fetchWorkers();
    }
  };

  const getPrimaryServiceImage = (serviceId: string): string | undefined => {
    const images = serviceImages[serviceId] || [];
    const primary = images.find(img => img.is_primary);
    return primary?.image_url || images[0]?.image_url;
  };

  const getPrimaryImage = (propertyId: string): string | undefined => {
    const images = propertyImages[propertyId] || [];
    const primary = images.find(img => img.is_primary);
    return primary?.image_url || images[0]?.image_url;
  };

  // Show loading while checking auth
  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Show access denied if user is not admin
  if (user && !isAdmin) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md text-center">
          <CardHeader>
            <ShieldX className="h-16 w-16 mx-auto text-destructive mb-4" />
            <CardTitle className="text-2xl">Access Denied</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground">
              You don't have admin privileges to access this panel.
              Please contact an administrator to request access.
            </p>
            <div className="flex gap-2 justify-center">
              <Button variant="outline" onClick={() => navigate("/")}>
                Go Home
              </Button>
              <Button variant="destructive" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" /> Sign Out
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile-Optimized Header */}
      <header className="bg-primary text-primary-foreground py-3 md:py-4 sticky top-0 z-50 shadow-md">
        <div className="container px-4">
          <div className="flex items-center justify-between">
            <h1 className="text-base md:text-xl font-bold truncate">Kings City Admin</h1>
            <div className="flex items-center gap-2 md:gap-4">
              <span className="text-xs md:text-sm hidden sm:block truncate max-w-[120px] md:max-w-none opacity-80">{user?.email}</span>
              <Button
                variant="ghost"
                onClick={handleLogout}
                className="text-primary-foreground hover:bg-primary/80 px-2 md:px-4"
                size="sm"
              >
                <LogOut className="h-4 w-4 md:mr-2" />
                <span className="hidden md:inline">Logout</span>
              </Button>
            </div>
          </div>
          {/* Mobile email display */}
          <p className="text-xs text-primary-foreground/70 mt-1 sm:hidden truncate">{user?.email}</p>
        </div>
      </header>

      <main className="container px-4 py-4 md:py-8">
        <Tabs defaultValue="properties" className="w-full">
          {/* Horizontal scrolling tabs for mobile */}
          <div className="relative mb-4 md:mb-6">
            <ScrollArea className="w-full pb-2">
              <TabsList className="inline-flex w-max min-w-full md:w-auto md:min-w-0 h-auto p-1 bg-muted/50 gap-1">
                <TabsTrigger value="properties" className="flex-shrink-0 px-3 py-2 text-xs md:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                  <Building2 className="h-3.5 w-3.5 md:h-4 md:w-4 mr-1.5" />
                  <span>Properties</span>
                </TabsTrigger>
                <TabsTrigger value="services" className="flex-shrink-0 px-3 py-2 text-xs md:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                  <ImageIcon className="h-3.5 w-3.5 md:h-4 md:w-4 mr-1.5" />
                  <span>Services</span>
                </TabsTrigger>
                <TabsTrigger value="workers" className="flex-shrink-0 px-3 py-2 text-xs md:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                  <UserCircle className="h-3.5 w-3.5 md:h-4 md:w-4 mr-1.5" />
                  <span>Workers</span>
                </TabsTrigger>
                <TabsTrigger value="affiliates" className="flex-shrink-0 px-3 py-2 text-xs md:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                  <Building2 className="h-3.5 w-3.5 md:h-4 md:w-4 mr-1.5" />
                  <span>Affiliates</span>
                </TabsTrigger>
                <TabsTrigger value="users" className="flex-shrink-0 px-3 py-2 text-xs md:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                  <Users className="h-3.5 w-3.5 md:h-4 md:w-4 mr-1.5" />
                  <span>Users</span>
                </TabsTrigger>
              </TabsList>
            </ScrollArea>
          </div>

          <TabsContent value="properties">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-4 md:mb-6">
              <h2 className="text-lg md:text-xl font-semibold">Manage Properties</h2>
              <Dialog open={propertyDialogOpen} onOpenChange={(open) => { setPropertyDialogOpen(open); if (!open) resetPropertyForm(); }}>
                <DialogTrigger asChild>
                  <Button><Plus className="h-4 w-4 mr-2" /> Add Property</Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] flex flex-col">
                  <DialogHeader className="flex-shrink-0">
                    <DialogTitle>{editingProperty ? "Edit Property" : "Add New Property"}</DialogTitle>
                  </DialogHeader>
                  <ScrollArea className="h-[50vh] pr-4 overflow-y-auto">
                    <form onSubmit={handlePropertySubmit} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="title">Title *</Label>
                          <Input id="title" value={propertyForm.title} onChange={(e) => setPropertyForm({ ...propertyForm, title: e.target.value })} required />
                        </div>
                        <div>
                          <Label htmlFor="location">Location *</Label>
                          <Input id="location" value={propertyForm.location} onChange={(e) => setPropertyForm({ ...propertyForm, location: e.target.value })} required />
                        </div>
                        <div>
                          <Label htmlFor="price">Price (GHS) *</Label>
                          <Input id="price" type="number" value={propertyForm.price} onChange={(e) => setPropertyForm({ ...propertyForm, price: e.target.value })} required />
                        </div>
                        <div>
                          <Label htmlFor="bedrooms">Bedrooms</Label>
                          <Input id="bedrooms" type="number" value={propertyForm.bedrooms} onChange={(e) => setPropertyForm({ ...propertyForm, bedrooms: e.target.value })} />
                        </div>
                        <div>
                          <Label htmlFor="bathrooms">Bathrooms</Label>
                          <Input id="bathrooms" type="number" value={propertyForm.bathrooms} onChange={(e) => setPropertyForm({ ...propertyForm, bathrooms: e.target.value })} />
                        </div>
                        <div>
                          <Label htmlFor="area_sqft">Area (sqft)</Label>
                          <Input id="area_sqft" type="number" value={propertyForm.area_sqft} onChange={(e) => setPropertyForm({ ...propertyForm, area_sqft: e.target.value })} />
                        </div>
                        <div>
                          <Label htmlFor="acres">Acres</Label>
                          <Input id="acres" type="number" step="0.01" value={propertyForm.acres} onChange={(e) => setPropertyForm({ ...propertyForm, acres: e.target.value })} />
                        </div>
                        <div>
                          <Label htmlFor="property_type">Listing Type *</Label>
                          <Select
                            onValueChange={(value) => setPropertyForm({ ...propertyForm, property_type: value })}
                            value={propertyForm.property_type}
                          >
                            <SelectTrigger id="property_type">
                              <SelectValue placeholder="Select type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="sale">
                                <div className="flex items-center">
                                  <Home className="h-4 w-4 mr-2 text-blue-500" />
                                  For Sale
                                </div>
                              </SelectItem>
                              <SelectItem value="rent">
                                <div className="flex items-center">
                                  <Key className="h-4 w-4 mr-2 text-green-500" />
                                  For Rent
                                </div>
                              </SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="description">Description</Label>
                        <Textarea id="description" value={propertyForm.description} onChange={(e) => setPropertyForm({ ...propertyForm, description: e.target.value })} rows={3} />
                      </div>

                      {/* Property Images */}
                      <div>
                        <Label>Property Images</Label>
                        <div className="mt-2 space-y-4">
                          {/* Existing Images */}
                          {existingPropertyImages.length > 0 && (
                            <div className="grid grid-cols-4 gap-2">
                              {existingPropertyImages.map((img) => (
                                <div key={img.id} className="relative group">
                                  <img src={img.image_url} alt="Property" className="w-full h-20 object-cover rounded" />
                                  <button
                                    type="button"
                                    onClick={() => removeExistingPropertyImage(img.id)}
                                    className="absolute top-1 right-1 bg-destructive text-destructive-foreground rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                                  >
                                    <X className="h-3 w-3" />
                                  </button>
                                  {img.is_primary && (
                                    <span className="absolute bottom-1 left-1 bg-primary text-primary-foreground text-xs px-1 rounded">Primary</span>
                                  )}
                                </div>
                              ))}
                            </div>
                          )}

                          {/* New Image Previews */}
                          {propertyImagePreviews.length > 0 && (
                            <div className="grid grid-cols-4 gap-2">
                              {propertyImagePreviews.map((preview, index) => (
                                <div key={index} className="relative group">
                                  <img src={preview} alt="Preview" className="w-full h-20 object-cover rounded" />
                                  <button
                                    type="button"
                                    onClick={() => removePropertyImagePreview(index)}
                                    className="absolute top-1 right-1 bg-destructive text-destructive-foreground rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                                  >
                                    <X className="h-3 w-3" />
                                  </button>
                                </div>
                              ))}
                            </div>
                          )}

                          <input
                            ref={propertyImageRef}
                            type="file"
                            accept="image/*"
                            multiple
                            onChange={handlePropertyImageSelect}
                            className="hidden"
                          />
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => propertyImageRef.current?.click()}
                            className="w-full"
                          >
                            <Upload className="h-4 w-4 mr-2" /> Add Images
                          </Button>
                        </div>
                      </div>

                      <div className="flex items-center gap-6">
                        <div className="flex items-center space-x-2">
                          <Switch id="is_available" checked={propertyForm.is_available} onCheckedChange={(checked) => setPropertyForm({ ...propertyForm, is_available: checked })} />
                          <Label htmlFor="is_available">Available</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch id="is_featured" checked={propertyForm.is_featured} onCheckedChange={(checked) => setPropertyForm({ ...propertyForm, is_featured: checked })} />
                          <Label htmlFor="is_featured">Featured</Label>
                        </div>
                      </div>
                      <div className="flex gap-2 pt-4">
                        <Button type="submit" disabled={uploading} className="flex-1">
                          {uploading ? "Saving..." : editingProperty ? "Update Property" : "Add Property"}
                        </Button>
                        <Button type="button" variant="outline" onClick={() => setPropertyDialogOpen(false)}>Cancel</Button>
                      </div>
                    </form>
                  </ScrollArea>
                </DialogContent>
              </Dialog>
            </div>

            {loading ? (
              <div className="text-center py-8">Loading properties...</div>
            ) : (
              <>
                {/* Mobile Card View */}
                <div className="grid gap-3 md:hidden">
                  {properties.map((property) => (
                    <Card key={property.id} className="overflow-hidden">
                      <div className="flex">
                        <div className="w-24 h-24 flex-shrink-0">
                          {getPrimaryImage(property.id) ? (
                            <img
                              src={getPrimaryImage(property.id)}
                              alt={property.title}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full bg-muted flex items-center justify-center">
                              <ImageIcon className="h-6 w-6 text-muted-foreground" />
                            </div>
                          )}
                        </div>
                        <div className="flex-1 p-3">
                          <h3 className="font-medium text-sm truncate">{property.title}</h3>
                          <p className="text-xs text-muted-foreground truncate">{property.location}</p>
                          <p className="text-sm font-semibold text-primary mt-1">GHS {property.price.toLocaleString()}</p>
                          <div className="flex items-center gap-2 mt-2">
                            <span className={`px-2 py-0.5 rounded text-xs ${property.is_available ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400" : "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400"}`}>
                              {property.is_available ? "Available" : "Sold"}
                            </span>
                            {property.is_featured && (
                              <span className="px-2 py-0.5 rounded text-xs bg-primary/10 text-primary">Featured</span>
                            )}
                          </div>
                        </div>
                        <div className="flex flex-col justify-center gap-1 pr-2">
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openPropertyEdit(property)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => deleteProperty(property.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>

                {/* Desktop Table View */}
                <Table className="hidden md:table">
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-20">Image</TableHead>
                      <TableHead>Title</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {properties.map((property) => (
                      <TableRow key={property.id}>
                        <TableCell>
                          {getPrimaryImage(property.id) ? (
                            <img
                              src={getPrimaryImage(property.id)}
                              alt={property.title}
                              className="w-16 h-12 object-cover rounded"
                            />
                          ) : (
                            <div className="w-16 h-12 bg-muted rounded flex items-center justify-center">
                              <ImageIcon className="h-4 w-4 text-muted-foreground" />
                            </div>
                          )}
                        </TableCell>
                        <TableCell className="font-medium">{property.title}</TableCell>
                        <TableCell>{property.location}</TableCell>
                        <TableCell>GHS {property.price.toLocaleString()}</TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded text-xs ${property.is_available ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400" : "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400"}`}>
                            {property.is_available ? "Available" : "Sold"}
                          </span>
                          {property.is_featured && (
                            <span className="ml-2 px-2 py-1 rounded text-xs bg-primary/10 text-primary">Featured</span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm" onClick={() => openPropertyEdit(property)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" className="text-destructive" onClick={() => deleteProperty(property.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </>
            )}
          </TabsContent>

          <TabsContent value="services">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-4 md:mb-6">
              <h2 className="text-lg md:text-xl font-semibold">Manage Service Images</h2>
              <Dialog open={serviceDialogOpen} onOpenChange={(open) => { setServiceDialogOpen(open); if (!open) resetServiceForm(); }}>
                <DialogContent className="max-w-2xl max-h-[90vh] flex flex-col">
                  <DialogHeader className="flex-shrink-0">
                    <DialogTitle>Manage Images - {editingService?.name}</DialogTitle>
                  </DialogHeader>
                  <ScrollArea className="h-[50vh] pr-4 overflow-y-auto">
                    <form onSubmit={handleServiceSubmit} className="space-y-4">
                      <div>
                        <Label>Service Name</Label>
                        <Input value={serviceForm.name} disabled className="bg-muted" />
                      </div>

                      {/* Service Images */}
                      <div>
                        <Label>Service Images</Label>
                        <div className="mt-2 space-y-4">
                          {/* Existing Images */}
                          {existingServiceImages.length > 0 && (
                            <div>
                              <p className="text-sm text-muted-foreground mb-2">Existing images:</p>
                              <div className="flex flex-wrap gap-2">
                                {existingServiceImages.map((img) => (
                                  <div key={img.id} className="relative">
                                    <img src={img.image_url} alt="Service" className="w-24 h-20 object-cover rounded" />
                                    <button
                                      type="button"
                                      onClick={() => removeExistingServiceImage(img.id)}
                                      className="absolute top-1 right-1 bg-destructive text-destructive-foreground rounded-full p-1"
                                    >
                                      <X className="h-3 w-3" />
                                    </button>
                                    {img.is_primary && (
                                      <span className="absolute bottom-1 left-1 bg-primary text-primary-foreground text-xs px-1 rounded">Primary</span>
                                    )}
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* New Image Previews */}
                          {serviceImagePreviews.length > 0 && (
                            <div>
                              <p className="text-sm text-muted-foreground mb-2">New images to upload:</p>
                              <div className="flex flex-wrap gap-2">
                                {serviceImagePreviews.map((preview, index) => (
                                  <div key={index} className="relative">
                                    <img src={preview} alt="Preview" className="w-24 h-20 object-cover rounded" />
                                    <button
                                      type="button"
                                      onClick={() => removeServiceImagePreview(index)}
                                      className="absolute top-1 right-1 bg-destructive text-destructive-foreground rounded-full p-1"
                                    >
                                      <X className="h-3 w-3" />
                                    </button>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}

                          <input
                            ref={serviceImageRef}
                            type="file"
                            accept="image/*"
                            multiple
                            onChange={handleServiceImageSelect}
                            className="hidden"
                          />
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => serviceImageRef.current?.click()}
                            className="w-full"
                          >
                            <Upload className="h-4 w-4 mr-2" /> Add Images
                          </Button>
                        </div>
                      </div>

                      <div className="flex gap-2 pt-4">
                        <Button type="submit" disabled={uploading} className="flex-1">
                          {uploading ? "Saving..." : "Save Images"}
                        </Button>
                        <Button type="button" variant="outline" onClick={() => setServiceDialogOpen(false)}>Cancel</Button>
                      </div>
                    </form>
                  </ScrollArea>
                </DialogContent>
              </Dialog>
            </div>

            {/* Mobile Card View for Services */}
            <div className="grid gap-3 md:hidden">
              {services.map((service) => (
                <Card key={service.id} className="overflow-hidden">
                  <div className="flex">
                    <div className="w-20 h-20 flex-shrink-0">
                      {getPrimaryServiceImage(service.id) ? (
                        <img
                          src={getPrimaryServiceImage(service.id)}
                          alt={service.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full bg-muted flex items-center justify-center">
                          <ImageIcon className="h-6 w-6 text-muted-foreground" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 p-3 flex flex-col justify-center">
                      <h3 className="font-medium text-sm">{service.name}</h3>
                      <p className="text-xs text-muted-foreground mt-1">
                        {serviceImages[service.id]?.length || 0} images
                      </p>
                    </div>
                    <div className="flex items-center pr-2">
                      <Button variant="ghost" size="sm" onClick={() => openServiceEdit(service)} className="text-xs">
                        <ImageIcon className="h-4 w-4 mr-1" /> Manage
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>

            {/* Desktop Table View for Services */}
            <Table className="hidden md:table">
              <TableHeader>
                <TableRow>
                  <TableHead className="w-20">Image</TableHead>
                  <TableHead>Service Name</TableHead>
                  <TableHead className="w-24">Images</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {services.map((service) => (
                  <TableRow key={service.id}>
                    <TableCell>
                      {getPrimaryServiceImage(service.id) ? (
                        <img
                          src={getPrimaryServiceImage(service.id)}
                          alt={service.name}
                          className="w-16 h-12 object-cover rounded"
                        />
                      ) : (
                        <div className="w-16 h-12 bg-muted rounded flex items-center justify-center">
                          <ImageIcon className="h-4 w-4 text-muted-foreground" />
                        </div>
                      )}
                    </TableCell>
                    <TableCell className="font-medium">{service.name}</TableCell>
                    <TableCell>
                      <span className="text-sm text-muted-foreground">
                        {serviceImages[service.id]?.length || 0} images
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm" onClick={() => openServiceEdit(service)}>
                        <ImageIcon className="h-4 w-4 mr-1" /> Manage Images
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TabsContent>

          <TabsContent value="workers">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-4 md:mb-6">
              <h2 className="text-lg md:text-xl font-semibold">Manage Workers</h2>
              <Dialog open={workerDialogOpen} onOpenChange={(open) => { setWorkerDialogOpen(open); if (!open) resetWorkerForm(); }}>
                <DialogTrigger asChild>
                  <Button size="sm" className="md:size-default"><Plus className="h-4 w-4 mr-2" /> Add Worker</Button>
                </DialogTrigger>
                <DialogContent className="max-w-lg max-h-[90vh] flex flex-col">
                  <DialogHeader className="flex-shrink-0">
                    <DialogTitle>{editingWorker ? "Edit Worker" : "Add New Worker"}</DialogTitle>
                  </DialogHeader>
                  <ScrollArea className="h-[50vh] pr-4 overflow-y-auto">
                    <form onSubmit={handleWorkerSubmit} className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="worker-name">Name *</Label>
                          <Input
                            id="worker-name"
                            value={workerForm.name}
                            onChange={(e) => setWorkerForm({ ...workerForm, name: e.target.value })}
                            required
                            placeholder="Full name"
                          />
                        </div>
                        <div>
                          <Label htmlFor="worker-position">Position *</Label>
                          <Input
                            id="worker-position"
                            value={workerForm.position}
                            onChange={(e) => setWorkerForm({ ...workerForm, position: e.target.value })}
                            required
                            placeholder="Job title"
                          />
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="worker-bio">Bio</Label>
                        <Textarea
                          id="worker-bio"
                          value={workerForm.bio}
                          onChange={(e) => setWorkerForm({ ...workerForm, bio: e.target.value })}
                          rows={3}
                          placeholder="Brief bio about the worker"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="worker-email">Email</Label>
                          <Input
                            id="worker-email"
                            type="email"
                            value={workerForm.email}
                            onChange={(e) => setWorkerForm({ ...workerForm, email: e.target.value })}
                            placeholder="email@example.com"
                          />
                        </div>
                        <div>
                          <Label htmlFor="worker-phone">Phone</Label>
                          <Input
                            id="worker-phone"
                            value={workerForm.phone}
                            onChange={(e) => setWorkerForm({ ...workerForm, phone: e.target.value })}
                            placeholder="+233..."
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="worker-order">Display Order</Label>
                          <Input
                            id="worker-order"
                            type="number"
                            value={workerForm.display_order}
                            onChange={(e) => setWorkerForm({ ...workerForm, display_order: e.target.value })}
                          />
                        </div>
                        <div>
                          <Label htmlFor="worker-category">Category</Label>
                          <select
                            id="worker-category"
                            className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                            value={workerForm.category}
                            onChange={(e) => setWorkerForm({ ...workerForm, category: e.target.value })}
                          >
                            <option value="team">Management Team</option>
                            <option value="board">Board of Directors</option>
                          </select>
                        </div>
                      </div>
                      <div>
                        <Label>Photo</Label>
                        <div className="mt-2 space-y-2">
                          {(workerPhotoPreview || workerForm.photo_url) && (
                            <div className="relative w-24 h-24">
                              <img
                                src={workerPhotoPreview || workerForm.photo_url}
                                alt="Photo preview"
                                className="w-full h-full object-cover rounded-full border"
                              />
                              <button
                                type="button"
                                onClick={() => {
                                  setWorkerPhotoFile(null);
                                  setWorkerPhotoPreview(null);
                                  setWorkerForm({ ...workerForm, photo_url: "" });
                                }}
                                className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground rounded-full p-1"
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </div>
                          )}
                          <input
                            ref={workerPhotoRef}
                            type="file"
                            accept="image/*"
                            onChange={handleWorkerPhotoSelect}
                            className="hidden"
                          />
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => workerPhotoRef.current?.click()}
                            size="sm"
                          >
                            <Upload className="h-4 w-4 mr-2" /> Upload Photo
                          </Button>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch
                          id="worker-active"
                          checked={workerForm.is_active}
                          onCheckedChange={(checked) => setWorkerForm({ ...workerForm, is_active: checked })}
                        />
                        <Label htmlFor="worker-active">Active (visible on website)</Label>
                      </div>
                      <div className="flex gap-2 pt-4">
                        <Button type="submit" disabled={uploading} className="flex-1">
                          {uploading ? "Saving..." : editingWorker ? "Update Worker" : "Add Worker"}
                        </Button>
                        <Button type="button" variant="outline" onClick={() => setWorkerDialogOpen(false)}>Cancel</Button>
                      </div>
                    </form>
                  </ScrollArea>
                </DialogContent>
              </Dialog>
            </div>

            {workersLoading ? (
              <div className="text-center py-8">
                <Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" />
                <p className="mt-2 text-muted-foreground">Loading workers...</p>
              </div>
            ) : (
              <>
                {/* Mobile Card View for Workers */}
                <div className="grid gap-3 md:hidden">
                  {workers.map((worker) => (
                    <Card key={worker.id} className="overflow-hidden">
                      <div className="flex">
                        <div className="w-16 h-16 flex-shrink-0 m-3">
                          {worker.photo_url ? (
                            <img
                              src={worker.photo_url}
                              alt={worker.name}
                              className="w-full h-full object-cover rounded-full"
                            />
                          ) : (
                            <div className="w-full h-full bg-muted rounded-full flex items-center justify-center">
                              <UserCircle className="h-8 w-8 text-muted-foreground" />
                            </div>
                          )}
                        </div>
                        <div className="flex-1 py-3 pr-2">
                          <div className="flex items-start justify-between">
                            <div>
                              <h3 className="font-medium text-sm">{worker.name}</h3>
                              <p className="text-xs text-muted-foreground">{worker.position}</p>
                              {worker.email && (
                                <p className="text-xs text-muted-foreground mt-1">{worker.email}</p>
                              )}
                            </div>
                            <span className={`px-2 py-0.5 rounded text-xs flex-shrink-0 ${worker.is_active ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' : 'bg-muted text-muted-foreground'}`}>
                              {worker.is_active ? 'Active' : 'Inactive'}
                            </span>
                          </div>
                          <div className="flex gap-1 mt-2">
                            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openWorkerEdit(worker)}>
                              <Pencil className="h-3.5 w-3.5" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => deleteWorker(worker.id)}>
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                  {workers.length === 0 && (
                    <Card className="p-8 text-center text-muted-foreground">
                      No workers found. Add your first team member.
                    </Card>
                  )}
                </div>

                {/* Desktop Table View for Workers */}
                <Table className="hidden md:table">
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-20">Photo</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Position</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {workers.map((worker) => (
                      <TableRow key={worker.id}>
                        <TableCell>
                          {worker.photo_url ? (
                            <img
                              src={worker.photo_url}
                              alt={worker.name}
                              className="w-12 h-12 object-cover rounded-full"
                            />
                          ) : (
                            <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center">
                              <UserCircle className="h-6 w-6 text-muted-foreground" />
                            </div>
                          )}
                        </TableCell>
                        <TableCell>
                          <div>
                            <p className="font-medium">{worker.name}</p>
                            {worker.email && (
                              <p className="text-xs text-muted-foreground">{worker.email}</p>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>{worker.position}</TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded text-xs ${worker.is_active ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' : 'bg-muted text-muted-foreground'}`}>
                            {worker.is_active ? 'Active' : 'Inactive'}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm" onClick={() => openWorkerEdit(worker)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => deleteWorker(worker.id)} className="text-destructive">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                    {workers.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                          No workers found. Add your first team member.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </>
            )}
          </TabsContent>

          <TabsContent value="affiliates">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-4 md:mb-6">
              <h2 className="text-lg md:text-xl font-semibold">Manage Affiliates</h2>
              <Dialog open={affiliateDialogOpen} onOpenChange={(open) => { setAffiliateDialogOpen(open); if (!open) resetAffiliateForm(); }}>
                <DialogTrigger asChild>
                  <Button size="sm" className="md:size-default"><Plus className="h-4 w-4 mr-2" /> Add Affiliate</Button>
                </DialogTrigger>
                <DialogContent className="max-w-lg max-h-[90vh] flex flex-col">
                  <DialogHeader className="flex-shrink-0">
                    <DialogTitle>{editingAffiliate ? "Edit Affiliate" : "Add New Affiliate"}</DialogTitle>
                  </DialogHeader>
                  <ScrollArea className="h-[50vh] pr-4 overflow-y-auto">
                    <form onSubmit={handleAffiliateSubmit} className="space-y-4">
                      <div>
                        <Label htmlFor="affiliate-name">Name *</Label>
                        <Input
                          id="affiliate-name"
                          value={affiliateForm.name}
                          onChange={(e) => setAffiliateForm({ ...affiliateForm, name: e.target.value })}
                          required
                          placeholder="Company name"
                        />
                      </div>
                      <div>
                        <Label htmlFor="affiliate-description">Description</Label>
                        <Textarea
                          id="affiliate-description"
                          value={affiliateForm.description}
                          onChange={(e) => setAffiliateForm({ ...affiliateForm, description: e.target.value })}
                          rows={3}
                          placeholder="Brief description of the company"
                        />
                      </div>
                      <div>
                        <Label htmlFor="affiliate-website">Website URL</Label>
                        <Input
                          id="affiliate-website"
                          type="url"
                          value={affiliateForm.website_url}
                          onChange={(e) => setAffiliateForm({ ...affiliateForm, website_url: e.target.value })}
                          placeholder="https://example.com"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="affiliate-category">Category</Label>
                          <select
                            id="affiliate-category"
                            className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm"
                            value={affiliateForm.category}
                            onChange={(e) => setAffiliateForm({ ...affiliateForm, category: e.target.value })}
                          >
                            <option value="partner">Partner</option>
                            <option value="company">Company</option>
                            <option value="sponsor">Sponsor</option>
                            <option value="supplier">Supplier</option>
                          </select>
                        </div>
                        <div>
                          <Label htmlFor="affiliate-order">Display Order</Label>
                          <Input
                            id="affiliate-order"
                            type="number"
                            value={affiliateForm.display_order}
                            onChange={(e) => setAffiliateForm({ ...affiliateForm, display_order: e.target.value })}
                          />
                        </div>
                      </div>
                      <div>
                        <Label>Logo</Label>
                        <div className="mt-2 space-y-2">
                          {(affiliateLogoPreview || affiliateForm.logo_url) && (
                            <div className="relative w-20 h-20">
                              <img
                                src={affiliateLogoPreview || affiliateForm.logo_url}
                                alt="Logo preview"
                                className="w-full h-full object-contain rounded border"
                              />
                              <button
                                type="button"
                                onClick={() => {
                                  setAffiliateLogoFile(null);
                                  setAffiliateLogoPreview(null);
                                  setAffiliateForm({ ...affiliateForm, logo_url: "" });
                                }}
                                className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1"
                              >
                                <X className="h-3 w-3" />
                              </button>
                            </div>
                          )}
                          <input
                            ref={affiliateLogoRef}
                            type="file"
                            accept="image/*"
                            onChange={handleAffiliateLogoSelect}
                            className="hidden"
                          />
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => affiliateLogoRef.current?.click()}
                            size="sm"
                          >
                            <Upload className="h-4 w-4 mr-2" /> Upload Logo
                          </Button>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch
                          id="affiliate-active"
                          checked={affiliateForm.is_active}
                          onCheckedChange={(checked) => setAffiliateForm({ ...affiliateForm, is_active: checked })}
                        />
                        <Label htmlFor="affiliate-active">Active (visible on website)</Label>
                      </div>
                      <div className="flex gap-2 pt-4">
                        <Button type="submit" disabled={uploading} className="flex-1">
                          {uploading ? "Saving..." : editingAffiliate ? "Update Affiliate" : "Add Affiliate"}
                        </Button>
                        <Button type="button" variant="outline" onClick={() => setAffiliateDialogOpen(false)}>Cancel</Button>
                      </div>
                    </form>
                  </ScrollArea>
                </DialogContent>
              </Dialog>
            </div>

            {affiliatesLoading ? (
              <div className="text-center py-8">
                <Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" />
                <p className="mt-2 text-muted-foreground">Loading affiliates...</p>
              </div>
            ) : (
              <>
                {/* Mobile Card View for Affiliates */}
                <div className="grid gap-3 md:hidden">
                  {affiliates.map((affiliate) => (
                    <Card key={affiliate.id} className="overflow-hidden">
                      <div className="flex">
                        <div className="w-16 h-16 flex-shrink-0 m-3">
                          {affiliate.logo_url ? (
                            <img
                              src={affiliate.logo_url}
                              alt={affiliate.name}
                              className="w-full h-full object-contain rounded"
                            />
                          ) : (
                            <div className="w-full h-full bg-muted rounded flex items-center justify-center">
                              <Building2 className="h-6 w-6 text-muted-foreground" />
                            </div>
                          )}
                        </div>
                        <div className="flex-1 py-3 pr-2">
                          <div className="flex items-start justify-between">
                            <div className="min-w-0">
                              <h3 className="font-medium text-sm truncate">{affiliate.name}</h3>
                              <p className="text-xs text-muted-foreground capitalize">{affiliate.category}</p>
                            </div>
                            <span className={`px-2 py-0.5 rounded text-xs flex-shrink-0 ml-2 ${affiliate.is_active ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' : 'bg-muted text-muted-foreground'}`}>
                              {affiliate.is_active ? 'Active' : 'Inactive'}
                            </span>
                          </div>
                          <div className="flex gap-1 mt-2">
                            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openAffiliateEdit(affiliate)}>
                              <Pencil className="h-3.5 w-3.5" />
                            </Button>
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => deleteAffiliate(affiliate.id)}>
                              <Trash2 className="h-3.5 w-3.5" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))}
                  {affiliates.length === 0 && (
                    <Card className="p-8 text-center text-muted-foreground">
                      No affiliates found. Add your first partner or company.
                    </Card>
                  )}
                </div>

                {/* Desktop Table View for Affiliates */}
                <Table className="hidden md:table">
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-20">Logo</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {affiliates.map((affiliate) => (
                      <TableRow key={affiliate.id}>
                        <TableCell>
                          {affiliate.logo_url ? (
                            <img
                              src={affiliate.logo_url}
                              alt={affiliate.name}
                              className="w-12 h-12 object-contain rounded"
                            />
                          ) : (
                            <div className="w-12 h-12 bg-muted rounded flex items-center justify-center">
                              <Building2 className="h-5 w-5 text-muted-foreground" />
                            </div>
                          )}
                        </TableCell>
                        <TableCell>
                          <div>
                            <p className="font-medium">{affiliate.name}</p>
                            {affiliate.website_url && (
                              <a
                                href={affiliate.website_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-xs text-muted-foreground hover:text-primary"
                              >
                                {affiliate.website_url}
                              </a>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="capitalize text-sm">{affiliate.category}</span>
                        </TableCell>
                        <TableCell>
                          <span className={`px-2 py-1 rounded text-xs ${affiliate.is_active ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' : 'bg-muted text-muted-foreground'}`}>
                            {affiliate.is_active ? 'Active' : 'Inactive'}
                          </span>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm" onClick={() => openAffiliateEdit(affiliate)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm" onClick={() => deleteAffiliate(affiliate.id)} className="text-destructive">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                    {affiliates.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                          No affiliates found. Add your first partner or company.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </>
            )}
          </TabsContent>

          <TabsContent value="users">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-4 md:mb-6">
              <h2 className="text-lg md:text-xl font-semibold">Manage Users</h2>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={fetchUsers} disabled={usersLoading} className="md:size-default">
                  {usersLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Refresh"}
                </Button>
                <Dialog open={userDialogOpen} onOpenChange={setUserDialogOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm" className="md:size-default"><Plus className="h-4 w-4 mr-2" /> Add User</Button>
                  </DialogTrigger>
                  <DialogContent className="max-h-[90vh] flex flex-col">
                    <DialogHeader className="flex-shrink-0">
                      <DialogTitle>Create New User</DialogTitle>
                    </DialogHeader>
                    <ScrollArea className="h-[50vh] pr-4 overflow-y-auto">
                      <form onSubmit={createUser} className="space-y-4">
                        <div>
                          <Label htmlFor="new-email">Email *</Label>
                          <Input
                            id="new-email"
                            type="email"
                            value={newUserForm.email}
                            onChange={(e) => setNewUserForm({ ...newUserForm, email: e.target.value })}
                            required
                            placeholder="user@example.com"
                          />
                        </div>
                        <div>
                          <Label htmlFor="new-password">Password *</Label>
                          <Input
                            id="new-password"
                            type="password"
                            value={newUserForm.password}
                            onChange={(e) => setNewUserForm({ ...newUserForm, password: e.target.value })}
                            required
                            minLength={6}
                            placeholder="Minimum 6 characters"
                          />
                        </div>
                        <div className="flex items-center space-x-2">
                          <Switch
                            id="make-admin"
                            checked={newUserForm.makeAdmin}
                            onCheckedChange={(checked) => setNewUserForm({ ...newUserForm, makeAdmin: checked })}
                          />
                          <Label htmlFor="make-admin">Make this user an admin</Label>
                        </div>
                        <div className="flex gap-2 pt-4">
                          <Button type="submit" disabled={creatingUser} className="flex-1">
                            {creatingUser ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Creating...</> : "Create User"}
                          </Button>
                          <Button type="button" variant="outline" onClick={() => setUserDialogOpen(false)}>Cancel</Button>
                        </div>
                      </form>
                    </ScrollArea>
                  </DialogContent>
                </Dialog>
              </div>
            </div>

            {usersLoading ? (
              <div className="text-center py-8">
                <Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" />
                <p className="mt-2 text-muted-foreground">Loading users...</p>
              </div>
            ) : (
              <>
                {/* Mobile Card View for Users */}
                <div className="grid gap-3 md:hidden">
                  {users.map((u) => (
                    <Card key={u.id} className="p-4">
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0 flex-1">
                          <p className="font-medium text-sm truncate">{u.email}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            Created: {new Date(u.created_at).toLocaleDateString()}
                          </p>
                          <div className="flex items-center gap-2 mt-2">
                            {u.roles.includes('admin') ? (
                              <span className="px-2 py-0.5 rounded text-xs bg-primary/10 text-primary flex items-center gap-1">
                                <ShieldCheck className="h-3 w-3" /> Admin
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded text-xs bg-muted text-muted-foreground">User</span>
                            )}
                          </div>
                        </div>
                        <div className="flex-shrink-0">
                          {u.roles.includes('admin') ? (
                            u.email === PROTECTED_ADMIN_EMAIL ? (
                              <span className="text-xs text-muted-foreground italic">Protected</span>
                            ) : (
                              <Button variant="ghost" size="sm" className="text-destructive text-xs h-8" onClick={() => removeAdminRole(u.id)} disabled={u.id === user?.id}>
                                <ShieldX className="h-3.5 w-3.5 mr-1" /> Remove
                              </Button>
                            )
                          ) : (
                            <Button variant="ghost" size="sm" className="text-xs h-8" onClick={() => addAdminRole(u.id)}>
                              <Shield className="h-3.5 w-3.5 mr-1" /> Make Admin
                            </Button>
                          )}
                        </div>
                      </div>
                    </Card>
                  ))}
                  {users.length === 0 && (
                    <Card className="p-8 text-center text-muted-foreground">
                      No users found. Click Refresh to load users.
                    </Card>
                  )}
                </div>

                {/* Desktop Table View for Users */}
                <Table className="hidden md:table">
                  <TableHeader>
                    <TableRow>
                      <TableHead>Email</TableHead>
                      <TableHead>Created</TableHead>
                      <TableHead>Last Sign In</TableHead>
                      <TableHead>Roles</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.map((u) => (
                      <TableRow key={u.id}>
                        <TableCell className="font-medium">{u.email}</TableCell>
                        <TableCell>{new Date(u.created_at).toLocaleDateString()}</TableCell>
                        <TableCell>{u.last_sign_in_at ? new Date(u.last_sign_in_at).toLocaleDateString() : "Never"}</TableCell>
                        <TableCell>
                          {u.roles.includes('admin') ? (
                            <span className="px-2 py-1 rounded text-xs bg-primary/10 text-primary flex items-center gap-1 w-fit">
                              <ShieldCheck className="h-3 w-3" /> Admin
                            </span>
                          ) : (
                            <span className="px-2 py-1 rounded text-xs bg-muted text-muted-foreground">User</span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          {u.roles.includes('admin') ? (
                            u.email === PROTECTED_ADMIN_EMAIL ? (
                              <span className="text-xs text-muted-foreground italic">Protected</span>
                            ) : (
                              <Button variant="ghost" size="sm" className="text-destructive" onClick={() => removeAdminRole(u.id)} disabled={u.id === user?.id}>
                                <ShieldX className="h-4 w-4 mr-1" /> Remove Admin
                              </Button>
                            )
                          ) : (
                            <Button variant="ghost" size="sm" onClick={() => addAdminRole(u.id)}>
                              <Shield className="h-4 w-4 mr-1" /> Make Admin
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                    {users.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                          No users found. Click Refresh to load users.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </>
            )}
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Admin;
