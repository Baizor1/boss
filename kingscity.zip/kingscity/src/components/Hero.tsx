import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import serviceConstruction from "@/assets/service-construction-new.jpg";
import serviceExterior from "@/assets/service-exterior-1.jpg";
import serviceInterior from "@/assets/service-interior-1.jpg";
import property1 from "@/assets/property-1.jpg";
import poolArea1 from "@/assets/pool-area-1.jpg";
import interiorStaircase1 from "@/assets/interior-staircase-1.jpg";
import cleaningServiceNew from "@/assets/service-cleaning-new.jpg";
import exteriorModern2 from "@/assets/exterior-modern-2.jpg";
import exteriorModern1 from "@/assets/exterior-modern-1.jpg";

const services = [
  {
    image: serviceConstruction,
    title: "General Construction",
    description: "Quality construction services for all your needs",
    link: "/services/general-construction"
  },
  {
    image: property1,
    title: "Real Estate Agency Services",
    description: "Professional real estate solutions",
    link: "/services/real-estate-agency"
  },
  {
    image: poolArea1,
    title: "Property/Asset Management",
    description: "Comprehensive property management services",
    link: "/services/property-management"
  },
  {
    image: interiorStaircase1,
    title: "Project Management & Supervision",
    description: "Expert project oversight and coordination",
    link: "/services/project-management"
  },
  {
    image: cleaningServiceNew,
    title: "Cleaning & Waste Management",
    description: "Professional cleaning and waste solutions",
    link: "/services/cleaning-waste-management"
  },
  {
    image: exteriorModern2,
    title: "Land / Quantity Surveying",
    description: "Accurate surveying and measurement services",
    link: "/services/land-surveying"
  },
  {
    image: exteriorModern1,
    title: "Real Estate Development",
    description: "Innovative real estate development projects",
    link: "/services/real-estate-development"
  },
  {
    image: serviceInterior,
    title: "Architectural, Interior & Landscape Designs",
    description: "Creative design solutions for your space",
    link: "/services/architectural-design"
  }
];

const Hero = () => {
  const [currentImage, setCurrentImage] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentImage((prev) => (prev + 1) % services.length);
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  const nextImage = () => {
    setCurrentImage((prev) => (prev + 1) % services.length);
  };

  const prevImage = () => {
    setCurrentImage((prev) => (prev - 1 + services.length) % services.length);
  };

  return (
    <section className="relative h-screen overflow-hidden">
      {/* Image Carousel */}
      <div className="absolute inset-0">
        {services.map((service, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentImage ? "opacity-100" : "opacity-0"
            }`}
          >
            <img
              src={service.image}
              alt={service.title}
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-black/30" />
          </div>
        ))}
      </div>

      {/* Navigation Arrows */}
      <button
        onClick={prevImage}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-20 p-2 rounded-full bg-white/20 backdrop-blur-sm hover:bg-white/30 transition-colors"
        aria-label="Previous image"
      >
        <ChevronLeft className="h-6 w-6 text-white" />
      </button>
      <button
        onClick={nextImage}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-20 p-2 rounded-full bg-white/20 backdrop-blur-sm hover:bg-white/30 transition-colors"
        aria-label="Next image"
      >
        <ChevronRight className="h-6 w-6 text-white" />
      </button>

      {/* Dots Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex gap-2">
        {services.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentImage(index)}
            className={`h-2 rounded-full transition-all ${
              index === currentImage
                ? "w-8 bg-white"
                : "w-2 bg-white/50 hover:bg-white/75"
            }`}
            aria-label={`Go to service ${index + 1}`}
          />
        ))}
      </div>

      {/* Content Overlay */}
      <div className="relative z-10 h-full flex items-center">
        <div className="container">
          <div className="max-w-3xl">
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 animate-fade-in">
              {services[currentImage].title}
            </h1>
            <p className="text-xl md:text-2xl text-white/90 mb-8 animate-fade-in">
              {services[currentImage].description}
            </p>
            <div className="flex flex-wrap gap-4 animate-fade-in">
              <Link to={services[currentImage].link}>
                <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 font-semibold">
                  Learn More
                </Button>
              </Link>
              <Link to="/contact">
                <Button size="lg" variant="outline" className="bg-white/10 text-white border-white hover:bg-white/20 backdrop-blur-sm">
                  Get a Quote
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
