import { Bed, Bath, Maximize, MapPin } from "lucide-react";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

interface PropertyCardProps {
  id: string;
  image: string;
  title: string;
  location: string;
  bedrooms: number;
  bathrooms: number;
  area: string;
  status?: "For Sale" | "For Rent" | "Sold";
}

const PropertyCard = ({
  id,
  image,
  title,
  location,
  bedrooms,
  bathrooms,
  area,
  status = "For Sale"
}: PropertyCardProps) => {
  return (
    <Link to={`/properties/${id}`} className="block">
    <Card className="group overflow-hidden border-border hover:shadow-xl transition-all duration-300">
      <div className="relative overflow-hidden aspect-[4/3]">
        <img 
          src={image} 
          alt={title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <Badge className="absolute top-4 left-4 bg-accent text-accent-foreground">
          {status}
        </Badge>
      </div>
      
      <CardContent className="p-5">
        <div className="mb-3">
          <h3 className="text-xl font-semibold text-primary mb-2 line-clamp-1">
            {title}
          </h3>
          <div className="flex items-center text-muted-foreground text-sm">
            <MapPin className="h-4 w-4 mr-1" />
            {location}
          </div>
        </div>
        
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Bed className="h-4 w-4" />
            <span>{bedrooms} Beds</span>
          </div>
          <div className="flex items-center gap-1">
            <Bath className="h-4 w-4" />
            <span>{bathrooms} Baths</span>
          </div>
          <div className="flex items-center gap-1">
            <Maximize className="h-4 w-4" />
            <span>{area}</span>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="p-5 pt-0">
        <Button variant="outline" className="w-full group-hover:bg-accent group-hover:text-accent-foreground group-hover:border-accent transition-colors">
          View Details
        </Button>
      </CardFooter>
    </Card>
    </Link>
  );
};

export default PropertyCard;
