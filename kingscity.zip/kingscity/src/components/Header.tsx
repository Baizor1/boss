import { Phone, Mail, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import logo from "@/assets/logo.jpg";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";

const Header = () => {
  const navLinks = [
    { to: "/properties", label: "Properties" },
    { to: "/about", label: "About Us" },
    { to: "/services", label: "Services" },
    { to: "/management", label: "Management" },
    { to: "/affiliates", label: "Affiliates" },
    { to: "/contact", label: "Contact" },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4 sm:px-8">
        <Link to="/" className="flex items-center gap-2 sm:gap-3 flex-shrink-0 mr-2">
          <img src={logo} alt="Kings City estates Logo" className="h-10 w-10 sm:h-12 sm:w-12 object-contain rounded-sm" />
          <div className="flex flex-col">
            <h1 className="text-[13px] sm:text-lg font-bold text-primary leading-none sm:leading-tight">Kings City Estates</h1>
            <p className="text-[9px] sm:text-xs text-muted-foreground font-medium uppercase tracking-wider">Premium Real Estate</p>
          </div>
        </Link>

        <nav className="hidden xl:flex items-center gap-1">
          {navLinks.map((link) => (
            <Link key={link.to} to={link.to}>
              <Button variant="ghost" size="sm" className="px-3 text-sm font-medium">
                {link.label}
              </Button>
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2 sm:gap-4">
          <a href="tel:+233243536135" className="hidden lg:flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-accent transition-colors">
            <Phone className="h-4 w-4" />
            <span className="hidden xl:inline">0243536135</span>
          </a>
          <Link to="/contact">
            <Button variant="default" size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90 px-3 sm:px-4 h-9 sm:h-10">
              <Mail className="h-4 w-4 sm:mr-2" />
              <span className="hidden sm:inline">Get in Touch</span>
            </Button>
          </Link>

          <Sheet>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="xl:hidden h-9 w-9"
              >
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[400px]">
              <SheetHeader>
                <SheetTitle className="text-left flex items-center gap-3 mb-6">
                  <img src={logo} alt="Logo" className="h-8 w-8 object-contain rounded-sm" />
                  <span>Kings City estates</span>
                </SheetTitle>
              </SheetHeader>
              <nav className="flex flex-col gap-4 mt-4">
                {navLinks.map((link) => (
                  <Link
                    key={link.to}
                    to={link.to}
                    className="flex items-center text-lg font-medium hover:text-accent transition-colors py-2 border-b border-muted/20"
                  >
                    {link.label}
                  </Link>
                ))}
                <div className="flex flex-col gap-4 mt-6 pt-6 border-t font-medium">
                  <a href="tel:+233243536135" className="flex items-center gap-3 text-muted-foreground hover:text-accent transition-colors">
                    <Phone className="h-5 w-5" />
                    <span>0243536135</span>
                  </a>
                  <p className="text-sm text-muted-foreground italic">Contact us for any inquiries!</p>
                </div>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
};

export default Header;
