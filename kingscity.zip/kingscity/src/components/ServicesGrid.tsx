import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

// Map service names to their routes
const serviceRoutes: Record<string, string> = {
  "General Construction": "/services/general-construction",
  "Real Estate Agency Service": "/services/real-estate-agency",
  "Property/Asset Management": "/services/property-management",
  "Project Management & Supervision": "/services/project-management",
  "Cleaning & Waste Management": "/services/cleaning-waste-management",
  "Real Estate Development": "/services/real-estate-development",
  "Land/Quantity Surveying": "/services/land-surveying",
  "Architectural & Landscape Designs": "/services/architectural-design",
};

// Map service names to descriptions
const serviceDescriptions: Record<string, string> = {
  "General Construction": "Quality construction services for all your needs",
  "Real Estate Agency Service": "Professional real estate solutions",
  "Property/Asset Management": "Comprehensive property management services",
  "Project Management & Supervision": "Expert project oversight and coordination",
  "Cleaning & Waste Management": "Professional cleaning and waste solutions",
  "Real Estate Development": "Innovative real estate development projects",
  "Land/Quantity Surveying": "Accurate surveying and measurement services",
  "Architectural & Landscape Designs": "Creative design solutions for your space",
};

const ServicesGrid = () => {
  const { data: services, isLoading } = useQuery({
    queryKey: ["services"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("services")
        .select("*")
        .order("created_at", { ascending: true });

      if (error) throw error;
      return data;
    },
  });

  return (
    <section className="py-20 bg-muted/30">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">Our Services</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            From custom home building to luxury interior design, we bring your vision to life
          </p>
        </div>
        
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="space-y-4">
                <Skeleton className="h-64 w-full rounded-lg" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-10 w-full" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services?.map((service) => {
              const link = serviceRoutes[service.name] || "/services";
              const description = serviceDescriptions[service.name] || "Professional service solutions";
              
              return (
                <Card key={service.id} className="overflow-hidden group hover:shadow-lg transition-shadow">
                  <div className="relative h-64 overflow-hidden">
                    <img
                      src={service.image_url || "/placeholder.svg"}
                      alt={service.name}
                      className="h-full w-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white mb-2">{service.name}</h3>
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <p className="text-muted-foreground mb-4">{description}</p>
                    <Link to={link}>
                      <Button variant="outline" className="w-full">
                        Learn More
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
};

export default ServicesGrid;
