import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import PropertyCard from "./PropertyCard";
import { Skeleton } from "@/components/ui/skeleton";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Search, SlidersHorizontal, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const PropertiesSection = () => {
  const [search, setSearch] = useState("");
  const [type, setType] = useState("all");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  const { data: properties, isLoading } = useQuery({
    queryKey: ["properties", search, type, minPrice, maxPrice],
    queryFn: async () => {
      let query = supabase
        .from("properties")
        .select(`
          *,
          property_images (
            id,
            image_url,
            is_primary
          )
        `)
        .eq("is_available", true);

      if (search) {
        query = query.or(`title.ilike.%${search}%,location.ilike.%${search}%`);
      }
      if (type !== "all") {
        query = query.eq("property_type", type);
      }
      if (minPrice) {
        query = query.gte("price", parseFloat(minPrice));
      }
      if (maxPrice) {
        query = query.lte("price", parseFloat(maxPrice));
      }

      const { data: propertiesData, error } = await query.order("created_at", { ascending: false });

      if (error) throw error;
      return propertiesData;
    },
  });

  const clearFilters = () => {
    setSearch("");
    setType("all");
    setMinPrice("");
    setMaxPrice("");
  };

  return (
    <section id="properties" className="py-16 md:py-24 bg-muted/30">
      <div className="container">
        <div className="text-center mb-8">
          <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
            Our Properties
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Discover premium real estate opportunities tailored to your lifestyle
          </p>
        </div>

        {/* Filter Section */}
        <div className="mb-12 space-y-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by title or location..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setShowFilters(!showFilters)}
                className={showFilters ? "bg-accent text-accent-foreground" : ""}
              >
                <SlidersHorizontal className="h-4 w-4 mr-2" />
                Filters
              </Button>
              {(search || type !== "all" || minPrice || maxPrice) && (
                <Button variant="ghost" onClick={clearFilters}>
                  <X className="h-4 w-4 mr-2" />
                  Clear
                </Button>
              )}
            </div>
          </div>

          {showFilters && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-6 bg-background rounded-xl border animate-in fade-in slide-in-from-top-4 duration-300">
              <div className="space-y-2">
                <label className="text-sm font-medium">Listing Type</label>
                <Select value={type} onValueChange={setType}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="sale">For Sale</SelectItem>
                    <SelectItem value="rent">For Rent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Min Price (GHS)</label>
                <Input
                  type="number"
                  placeholder="Min"
                  value={minPrice}
                  onChange={(e) => setMinPrice(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Max Price (GHS)</label>
                <Input
                  type="number"
                  placeholder="Max"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(e.target.value)}
                />
              </div>
            </div>
          )}
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="space-y-4">
                <Skeleton className="h-48 w-full rounded-lg" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {properties?.map((property) => {
              const primaryImage = property.property_images?.find((img) => img.is_primary);
              const firstImage = property.property_images?.[0];
              const imageUrl = primaryImage?.image_url || firstImage?.image_url || "/placeholder.svg";

              return (
                <PropertyCard
                  key={property.id}
                  id={property.id}
                  image={imageUrl}
                  title={property.title}
                  location={property.location}
                  bedrooms={property.bedrooms || 0}
                  bathrooms={property.bathrooms || 0}
                  area={property.area_sqft ? `${property.area_sqft.toLocaleString()} sq ft` : "N/A"}
                  status={!property.is_available ? "Sold" : (property.property_type === "rent" ? "For Rent" : "For Sale")}
                />
              );
            })}
            {properties?.length === 0 && (
              <div className="col-span-full py-12 text-center">
                <p className="text-lg text-muted-foreground">No properties found matching your criteria.</p>
                <Button variant="link" onClick={clearFilters} className="mt-2 text-primary font-semibold">
                  View all properties
                </Button>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
};

export default PropertiesSection;
