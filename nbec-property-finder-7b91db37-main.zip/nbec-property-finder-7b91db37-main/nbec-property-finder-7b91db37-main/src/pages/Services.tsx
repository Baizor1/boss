import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Building, 
  Home, 
  Briefcase, 
  Hammer, 
  Trash2, 
  PenTool, 
  Ruler, 
  TreePine,
  Shield,
  TrendingUp,
  Users,
  Wrench
} from "lucide-react";

const Services = () => {
  const services = [
    {
      icon: Hammer,
      title: "General Construction",
      description: "Comprehensive construction services with the highest quality craftsmanship and attention to detail for residential and commercial projects."
    },
    {
      icon: Home,
      title: "Real Estate Agency Service",
      description: "Professional real estate services including sales, leasing, and property acquisition across all property types in Ghana."
    },
    {
      icon: Briefcase,
      title: "Property/Asset Management",
      description: "Full-service property management with over GHS 2 billion in assets under management. We manage your property as if it were our own."
    },
    {
      icon: Users,
      title: "Project Management & Supervision",
      description: "Expert project management ensuring timely delivery, quality control, and adherence to specifications throughout construction."
    },
    {
      icon: Trash2,
      title: "Cleaning & Waste Management",
      description: "Professional cleaning and comprehensive waste management services for residential and commercial properties."
    },
    {
      icon: Building,
      title: "Real Estate Development",
      description: "Creating sustainable, innovative communities from master-planned developments to mixed-use urban regeneration projects."
    },
    {
      icon: Ruler,
      title: "Land/Quantity Surveying",
      description: "Accurate land surveying and quantity estimation services ensuring precise measurements and cost control."
    },
    {
      icon: PenTool,
      title: "Architectural & Landscape Designs",
      description: "Creative architectural design and landscape planning that combines functionality with aesthetic excellence."
    }
  ];

  const managementServices = [
    "Up to 40% Savings on Insurance",
    "24/7 Web Access to Accounting",
    "Aggressive Rent Collections",
    "Proactive Tenant Retention",
    "Ongoing Expense Reviews",
    "Comprehensive Monthly Reporting",
    "Property Tax Reduction",
    "Customized Management Services",
    "Lender Assistance",
    "Effective Cash Management",
    "Preventive Maintenance",
    "Construction Supervision",
    "Asset Valuation"
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="relative py-20 bg-gradient-to-br from-primary/10 via-background to-accent/10">
          <div className="container">
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-bold text-primary mb-6">
                Our Services
              </h1>
              <p className="text-xl text-muted-foreground">
                Comprehensive real estate and construction solutions tailored to your needs
              </p>
            </div>
          </div>
        </section>

        {/* Main Services */}
        <section className="py-16">
          <div className="container">
            <h2 className="text-3xl font-bold text-primary mb-12 text-center">
              What We Do Best
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {services.map((service, index) => {
                const Icon = service.icon;
                return (
                  <Card key={index} className="hover:border-accent transition-all hover:shadow-lg">
                    <CardHeader>
                      <Icon className="h-10 w-10 text-accent mb-3" />
                      <CardTitle className="text-xl">{service.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-sm">
                        {service.description}
                      </CardDescription>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        {/* Property Management Excellence */}
        <section className="py-16 bg-muted/30">
          <div className="container">
            <div className="max-w-5xl mx-auto">
              <div className="text-center mb-12">
                <Shield className="h-12 w-12 text-accent mx-auto mb-4" />
                <h2 className="text-3xl font-bold text-primary mb-4">
                  Property Management Excellence
                </h2>
                <p className="text-xl text-muted-foreground mb-2">
                  We Think Like Owners... Because We Are!
                </p>
                <p className="text-lg text-accent font-semibold">
                  More Than GHS 2 Billion of Assets Under Management
                </p>
              </div>

              <Card className="mb-8">
                <CardHeader>
                  <CardTitle className="text-2xl text-center">
                    We Earn Our Fee By Saving You Money!
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">
                    We understand the owner mentality inside out and because we own and manage more than 10,000,000 square feet of properties ourselves, we never lose sight of the bottom line. We work hard to make money and save money! Our services are the next best thing to managing it yourself.
                  </p>
                  <p className="text-muted-foreground">
                    The significant savings on insurance with our Master Policy Premiums alone reduces costs and practically pays for our management fee. We also provide owners with 24-hour access to comprehensive reports via our website.
                  </p>
                </CardContent>
              </Card>

              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {managementServices.map((service, index) => (
                  <div key={index} className="flex items-center gap-3 bg-card p-4 rounded-lg border">
                    <Wrench className="h-5 w-5 text-accent flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">{service}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Agent Specialization */}
        <section className="py-16">
          <div className="container">
            <div className="max-w-4xl mx-auto text-center">
              <TrendingUp className="h-12 w-12 text-accent mx-auto mb-4" />
              <h2 className="text-3xl font-bold text-primary mb-6">
                Agent Specialization
              </h2>
              <p className="text-lg text-muted-foreground mb-8">
                Our agents are specialized in their services by property type discipline, sales and leasing expertise, geographic area focus, and design and build technics.
              </p>
              <div className="bg-card p-8 rounded-lg border">
                <p className="text-muted-foreground">
                  Each Kings City estates manager and associate knows the buildings, property owners, buyers, building characteristics, market rents, vacancy factors, employment drivers, business growth, recent sales and demographics in their market area.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Service Locations */}
        <section className="py-16 bg-muted/30">
          <div className="container">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold text-primary mb-8 text-center">
                Serving Communities Across Ghana
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {[
                  "Accra", "East Legon", "Achimota", "Pokuase",
                  "North Kanashie", "Dansoman", "Airport Residential", "West Legon",
                  "Adenta", "Lapaz", "Dzowuru", "Greater Accra Region",
                  "Ashanti", "Eastern", "Central", "Western",
                  "Northern", "Brong Ahafo", "Tema", "Volta Region"
                ].map((location, index) => (
                  <div key={index} className="bg-card p-3 rounded-lg border text-center text-sm text-muted-foreground hover:border-accent transition-colors">
                    {location}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Services;
