import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ContactSection from "@/components/ContactSection";
import { useServiceImages } from "@/hooks/useServiceImages";
import { Skeleton } from "@/components/ui/skeleton";

// Fallback images
import property1 from "@/assets/property-1.jpg";
import property2 from "@/assets/property-2.jpg";
import property3 from "@/assets/property-3.jpg";
import property4 from "@/assets/property-4.jpg";
import property5 from "@/assets/property-5.jpg";
import property6 from "@/assets/property-6.jpg";

const fallbackImages = [
  property1,
  property2,
  property3,
  property4,
  property5,
  property6,
];

const ProjectManagement = () => {
  const { data: dbImages, isLoading } = useServiceImages("Project Management & Supervision");
  
  const images = dbImages && dbImages.length > 0 
    ? dbImages.map(img => img.image_url) 
    : fallbackImages;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="relative h-[60vh] overflow-hidden">
          <img
            src={images[0] || property1}
            alt="Project Management"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/30" />
          <div className="absolute inset-0 flex items-center">
            <div className="container">
              <h1 className="text-5xl md:text-7xl font-bold text-white mb-4">
                Project Management & Supervision
              </h1>
              <p className="text-xl text-white/90 max-w-2xl">
                Expert project oversight and coordination
              </p>
            </div>
          </div>
        </section>

        {/* Content Section */}
        <section className="py-20">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
              <div>
                <h2 className="text-3xl font-bold mb-6">Expert Project Supervision</h2>
                <p className="text-muted-foreground mb-4">
                  We provide comprehensive project management services to ensure your construction projects are completed on time, within budget, and to the highest standards.
                </p>
                <ul className="space-y-3 text-muted-foreground">
                  <li>• Project planning and scheduling</li>
                  <li>• Budget management</li>
                  <li>• Quality control</li>
                  <li>• Site supervision</li>
                  <li>• Risk management</li>
                </ul>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {isLoading ? (
                  <>
                    <Skeleton className="w-full h-64 rounded-lg" />
                    <Skeleton className="w-full h-64 rounded-lg" />
                  </>
                ) : (
                  <>
                    <img
                      src={images[1] || property2}
                      alt="Project planning"
                      className="rounded-lg w-full h-64 object-cover"
                    />
                    <img
                      src={images[2] || property3}
                      alt="Construction management"
                      className="rounded-lg w-full h-64 object-cover"
                    />
                  </>
                )}
              </div>
            </div>
            
            <div className="grid md:grid-cols-4 gap-6">
              {isLoading ? (
                Array(4).fill(0).map((_, i) => (
                  <Skeleton key={i} className="w-full h-64 rounded-lg" />
                ))
              ) : (
                images.slice(3, 7).map((img, index) => (
                  <img
                    key={index}
                    src={img}
                    alt={`Project ${index + 1}`}
                    className="rounded-lg w-full h-64 object-cover"
                  />
                ))
              )}
            </div>
          </div>
        </section>

        <ContactSection />
      </main>
      <Footer />
    </div>
  );
};

export default ProjectManagement;