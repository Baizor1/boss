import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ContactSection from "@/components/ContactSection";
import { useServiceImages } from "@/hooks/useServiceImages";
import { Skeleton } from "@/components/ui/skeleton";

// Fallback images
import serviceExterior4 from "@/assets/service-exterior-4.jpg";
import serviceExterior5 from "@/assets/service-exterior-5.jpg";
import serviceExterior6 from "@/assets/service-exterior-6.jpg";
import bathroomModern3 from "@/assets/bathroom-modern-3.jpg";
import bathroomModern4 from "@/assets/bathroom-modern-4.jpg";
import bathroomModern5 from "@/assets/bathroom-modern-5.jpg";

const fallbackImages = [
  serviceExterior4,
  serviceExterior5,
  serviceExterior6,
  bathroomModern3,
  bathroomModern4,
  bathroomModern5,
];

const CleaningWasteManagement = () => {
  const { data: dbImages, isLoading } = useServiceImages("Cleaning & Waste Management");
  
  const images = dbImages && dbImages.length > 0 
    ? dbImages.map(img => img.image_url) 
    : fallbackImages;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="relative h-[60vh] overflow-hidden">
          <img
            src={images[0] || serviceExterior4}
            alt="Cleaning & Waste Management"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/30" />
          <div className="absolute inset-0 flex items-center">
            <div className="container">
              <h1 className="text-5xl md:text-7xl font-bold text-white mb-4">
                Cleaning & Waste Management
              </h1>
              <p className="text-xl text-white/90 max-w-2xl">
                Professional cleaning and waste solutions
              </p>
            </div>
          </div>
        </section>

        {/* Content Section */}
        <section className="py-20">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
              <div>
                <h2 className="text-3xl font-bold mb-6">Professional Cleaning Services</h2>
                <p className="text-muted-foreground mb-4">
                  We offer comprehensive cleaning and waste management services for residential and commercial properties.
                </p>
                <ul className="space-y-3 text-muted-foreground">
                  <li>• Post-construction cleaning</li>
                  <li>• Regular maintenance cleaning</li>
                  <li>• Waste removal and disposal</li>
                  <li>• Deep cleaning services</li>
                  <li>• Eco-friendly solutions</li>
                </ul>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {isLoading ? (
                  <>
                    <Skeleton className="w-full h-64 rounded-lg" />
                    <Skeleton className="w-full h-64 rounded-lg" />
                  </>
                ) : (
                  <>
                    <img
                      src={images[1] || serviceExterior5}
                      alt="Cleaning services"
                      className="rounded-lg w-full h-64 object-cover"
                    />
                    <img
                      src={images[2] || serviceExterior6}
                      alt="Waste management"
                      className="rounded-lg w-full h-64 object-cover"
                    />
                  </>
                )}
              </div>
            </div>
            
            <div className="grid md:grid-cols-4 gap-6">
              {isLoading ? (
                Array(4).fill(0).map((_, i) => (
                  <Skeleton key={i} className="w-full h-64 rounded-lg" />
                ))
              ) : (
                images.slice(3, 7).map((img, index) => (
                  <img
                    key={index}
                    src={img}
                    alt={`Cleaning ${index + 1}`}
                    className="rounded-lg w-full h-64 object-cover"
                  />
                ))
              )}
            </div>
          </div>
        </section>

        <ContactSection />
      </main>
      <Footer />
    </div>
  );
};

export default CleaningWasteManagement;