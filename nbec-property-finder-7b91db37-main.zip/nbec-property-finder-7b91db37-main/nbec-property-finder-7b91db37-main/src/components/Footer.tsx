import { Mail, Phone, MessageCircle } from "lucide-react";
import { Link } from "react-router-dom";
import logo from "@/assets/logo.jpg";

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground py-12">
      <div className="container">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <img src={logo} alt="Kings City estates Logo" className="h-10 w-10 object-contain" />
              <span className="text-xl font-bold">Kings City estates</span>
            </div>
            <p className="text-primary-foreground/80">
              Your trusted partner in finding premium real estate across Ghana.
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2 text-primary-foreground/80">
              <li><Link to="/properties" className="hover:text-accent transition-colors">Properties</Link></li>
              <li><Link to="/about" className="hover:text-accent transition-colors">About Us</Link></li>
              <li><Link to="/services" className="hover:text-accent transition-colors">Services</Link></li>
              <li><Link to="/contact" className="hover:text-accent transition-colors">Contact</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Contact Info</h3>
            <ul className="space-y-2 text-primary-foreground/80">
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                <a href="tel:+233303970732" className="hover:text-accent transition-colors">(+233(0)303970732)</a>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                <a href="tel:+233243536135" className="hover:text-accent transition-colors">0243536135</a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                <a href="mailto:kingscityestate@gmail.com" className="hover:text-accent transition-colors break-all">
                  kingscityestate@gmail.com
                </a>
              </li>
              <li className="flex items-center gap-2 group">
                <MessageCircle className="h-4 w-4 text-green-500 group-hover:text-green-400 transition-colors" />
                <a href="https://wa.me/233243536135" target="_blank" rel="noopener noreferrer" className="text-green-500 hover:text-green-400 transition-colors">
                  WhatsApp Us
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-primary-foreground/20 text-center text-primary-foreground/60">
          <p>&copy; {new Date().getFullYear()} Kings City estates. <Link to="/admin" className="hover:text-primary-foreground/80 transition-colors cursor-pointer">All rights reserved.</Link></p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
