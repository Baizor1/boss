import { Phone, Mail, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Link } from "react-router-dom";
import logo from "@/assets/logo.jpg";

const Header = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { to: "/properties", label: "Properties" },
    { to: "/about", label: "About Us" },
    { to: "/services", label: "Services" },
    { to: "/management", label: "Management" },
    { to: "/affiliates", label: "Affiliates" },
    { to: "/contact", label: "Contact" },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-3">
          <img src={logo} alt="Kings City estates Logo" className="h-12 w-12 object-contain" />
          <div>
            <h1 className="text-lg font-bold text-primary">Kings City estates</h1>
            <p className="text-xs text-muted-foreground">Premium Real Estate</p>
          </div>
        </Link>
        
        <nav className="hidden lg:flex items-center gap-3">
          {navLinks.map((link) => (
            <Link key={link.to} to={link.to}>
              <Button variant="outline" size="sm">
                {link.label}
              </Button>
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a href="tel:+233243536135" className="hidden lg:flex items-center gap-2 text-sm text-muted-foreground hover:text-accent transition-colors">
            <Phone className="h-4 w-4" />
            <span>0243536135</span>
          </a>
          <Link to="/contact" className="hidden sm:block">
            <Button variant="default" size="sm" className="bg-accent text-accent-foreground hover:bg-accent/90">
              <Mail className="h-4 w-4 mr-2" />
              Get in Touch
            </Button>
          </Link>
          
          {/* Mobile/Tablet menu button */}
          <Button
            variant="ghost"
            size="sm"
            className="lg:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>
      </div>

      {/* Mobile/Tablet menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t bg-background">
          <nav className="container py-4 flex flex-col gap-2">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                onClick={() => setMobileMenuOpen(false)}
              >
                <Button variant="ghost" className="w-full justify-start">
                  {link.label}
                </Button>
              </Link>
            ))}
            <a href="tel:+233243536135" className="flex items-center gap-2 px-4 py-2 text-sm text-muted-foreground">
              <Phone className="h-4 w-4" />
              <span>0243536135</span>
            </a>
            <Link to="/contact" onClick={() => setMobileMenuOpen(false)}>
              <Button variant="default" size="sm" className="w-full bg-accent text-accent-foreground hover:bg-accent/90">
                <Mail className="h-4 w-4 mr-2" />
                Get in Touch
              </Button>
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
