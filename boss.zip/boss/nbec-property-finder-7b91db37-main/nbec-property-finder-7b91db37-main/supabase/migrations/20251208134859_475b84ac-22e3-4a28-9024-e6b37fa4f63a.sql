-- Make the property-images bucket public
UPDATE storage.buckets SET public = true WHERE id = 'property-images';

-- Create storage policies for property-images bucket
CREATE POLICY "Allow public read access on property-images" 
ON storage.objects FOR SELECT 
USING (bucket_id = 'property-images');

CREATE POLICY "Allow authenticated uploads to property-images" 
ON storage.objects FOR INSERT 
WITH CHECK (bucket_id = 'property-images');

CREATE POLICY "Allow authenticated updates to property-images" 
ON storage.objects FOR UPDATE 
USING (bucket_id = 'property-images');

CREATE POLICY "Allow authenticated deletes from property-images" 
ON storage.objects FOR DELETE 
USING (bucket_id = 'property-images');

-- Enable RLS on properties table (public read, no write restrictions for admin)
ALTER TABLE properties ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read access on properties" 
ON properties FOR SELECT 
USING (true);

CREATE POLICY "Allow all operations on properties" 
ON properties FOR ALL 
USING (true) WITH CHECK (true);

-- Enable RLS on services table
ALTER TABLE services ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read access on services" 
ON services FOR SELECT 
USING (true);

CREATE POLICY "Allow all operations on services" 
ON services FOR ALL 
USING (true) WITH CHECK (true);

-- Enable RLS on property_images table
ALTER TABLE property_images ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read access on property_images" 
ON property_images FOR SELECT 
USING (true);

CREATE POLICY "Allow all operations on property_images" 
ON property_images FOR ALL 
USING (true) WITH CHECK (true);