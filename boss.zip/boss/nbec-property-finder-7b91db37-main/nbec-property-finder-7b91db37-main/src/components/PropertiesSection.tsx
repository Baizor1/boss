import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import PropertyCard from "./PropertyCard";
import { Skeleton } from "@/components/ui/skeleton";

const PropertiesSection = () => {
  const { data: properties, isLoading } = useQuery({
    queryKey: ["properties"],
    queryFn: async () => {
      const { data: propertiesData, error } = await supabase
        .from("properties")
        .select(`
          *,
          property_images (
            id,
            image_url,
            is_primary
          )
        `)
        .eq("is_available", true)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return propertiesData;
    },
  });

  return (
    <section id="properties" className="py-16 md:py-24 bg-muted/30">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
            Featured Properties
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Explore our handpicked selection of premium properties across Ghana
          </p>
        </div>
        
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="space-y-4">
                <Skeleton className="h-48 w-full rounded-lg" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {properties?.map((property) => {
              const primaryImage = property.property_images?.find((img) => img.is_primary);
              const firstImage = property.property_images?.[0];
              const imageUrl = primaryImage?.image_url || firstImage?.image_url || "/placeholder.svg";
              
              return (
                <PropertyCard
                  key={property.id}
                  id={property.id}
                  image={imageUrl}
                  title={property.title}
                  location={property.location}
                  bedrooms={property.bedrooms || 0}
                  bathrooms={property.bathrooms || 0}
                  area={property.area_sqft ? `${property.area_sqft.toLocaleString()} sq ft` : "N/A"}
                  status={property.is_available ? "For Sale" : "Sold"}
                />
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
};

export default PropertiesSection;
