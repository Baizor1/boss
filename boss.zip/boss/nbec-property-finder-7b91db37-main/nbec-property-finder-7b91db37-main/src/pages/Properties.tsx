import Header from "@/components/Header";
import Footer from "@/components/Footer";
import PropertiesSection from "@/components/PropertiesSection";

const Properties = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="pt-16">
        <div className="bg-gradient-to-br from-secondary/30 via-background to-secondary/20 py-16">
          <div className="container">
            <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">
              Our Properties
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl">
              Browse our exclusive collection of premium properties across Ghana. From luxury villas to modern apartments, find your perfect space.
            </p>
          </div>
        </div>
        <PropertiesSection />
      </main>
      <Footer />
    </div>
  );
};

export default Properties;
