import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ContactSection from "@/components/ContactSection";
import { useServiceImages } from "@/hooks/useServiceImages";
import { Skeleton } from "@/components/ui/skeleton";

// Fallback images
import poolArea1 from "@/assets/pool-area-1.jpg";
import poolArea2 from "@/assets/pool-area-2.jpg";
import exteriorPool1 from "@/assets/exterior-pool-1.jpg";
import bedroom1 from "@/assets/bedroom-1.jpg";
import bedroom2 from "@/assets/bedroom-2.jpg";
import bedroom3 from "@/assets/bedroom-3.jpg";

const fallbackImages = [
  poolArea1,
  poolArea2,
  exteriorPool1,
  bedroom1,
  bedroom2,
  bedroom3,
];

const PropertyManagement = () => {
  const { data: dbImages, isLoading } = useServiceImages("Property/Asset Management");
  
  const images = dbImages && dbImages.length > 0 
    ? dbImages.map(img => img.image_url) 
    : fallbackImages;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        {/* Hero Section */}
        <section className="relative h-[60vh] overflow-hidden">
          <img
            src={images[0] || poolArea1}
            alt="Property Management"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/30" />
          <div className="absolute inset-0 flex items-center">
            <div className="container">
              <h1 className="text-5xl md:text-7xl font-bold text-white mb-4">
                Property/Asset Management
              </h1>
              <p className="text-xl text-white/90 max-w-2xl">
                Comprehensive property management services
              </p>
            </div>
          </div>
        </section>

        {/* Content Section */}
        <section className="py-20">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
              <div>
                <h2 className="text-3xl font-bold mb-6">Professional Property Management</h2>
                <p className="text-muted-foreground mb-4">
                  Our property management services ensure your assets are well-maintained and generating optimal returns.
                </p>
                <ul className="space-y-3 text-muted-foreground">
                  <li>• Tenant screening and management</li>
                  <li>• Maintenance coordination</li>
                  <li>• Rent collection</li>
                  <li>• Financial reporting</li>
                  <li>• Property inspections</li>
                </ul>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {isLoading ? (
                  <>
                    <Skeleton className="w-full h-64 rounded-lg" />
                    <Skeleton className="w-full h-64 rounded-lg" />
                  </>
                ) : (
                  <>
                    <img
                      src={images[1] || poolArea2}
                      alt="Managed property"
                      className="rounded-lg w-full h-64 object-cover"
                    />
                    <img
                      src={images[2] || exteriorPool1}
                      alt="Asset management"
                      className="rounded-lg w-full h-64 object-cover"
                    />
                  </>
                )}
              </div>
            </div>
            
            <div className="grid md:grid-cols-4 gap-6">
              {isLoading ? (
                Array(4).fill(0).map((_, i) => (
                  <Skeleton key={i} className="w-full h-64 rounded-lg" />
                ))
              ) : (
                images.slice(3, 7).map((img, index) => (
                  <img
                    key={index}
                    src={img}
                    alt={`Property ${index + 1}`}
                    className="rounded-lg w-full h-64 object-cover"
                  />
                ))
              )}
            </div>
          </div>
        </section>

        <ContactSection />
      </main>
      <Footer />
    </div>
  );
};

export default PropertyManagement;