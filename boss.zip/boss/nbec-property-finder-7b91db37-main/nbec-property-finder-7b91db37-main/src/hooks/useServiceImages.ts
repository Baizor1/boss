import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

// Service name to ID mapping based on database
const SERVICE_IDS: Record<string, string> = {
  "General Construction": "e5fb2756-cb53-4926-bac0-cedcc5af65f1",
  "Real Estate Agency Service": "8a1a20ad-cc54-4651-9242-25bc8c4ef761",
  "Property/Asset Management": "968c1531-e9c6-4910-ad40-4b34ebba1226",
  "Project Management & Supervision": "0e0cb8d6-481b-4b6a-8937-40c514e371dc",
  "Land/Quantity Surveying": "02cc7690-c9a2-446c-8b31-6c117fd0ee9a",
  "Real Estate Development": "f94dc5f3-3b76-4daf-b256-da9c0935f119",
  "Cleaning & Waste Management": "4e361150-640d-4c06-89d5-012cc7ea60d4",
  "Architectural & Landscape Designs": "162dd986-3aef-4aff-9ef6-cd71d9bde247",
};

export const useServiceImages = (serviceName: string) => {
  const serviceId = SERVICE_IDS[serviceName];

  return useQuery({
    queryKey: ["service-images", serviceId],
    queryFn: async () => {
      if (!serviceId) return [];
      
      const { data, error } = await supabase
        .from("service_images")
        .select("*")
        .eq("service_id", serviceId)
        .order("is_primary", { ascending: false });

      if (error) {
        console.error("Error fetching service images:", error);
        return [];
      }

      return data || [];
    },
    enabled: !!serviceId,
  });
};

export const getServiceId = (serviceName: string) => SERVICE_IDS[serviceName];
