#!/usr/bin/env python3
"""
Simple HTTP server with URL routing support for clean URLs
Supports serving HTML files without .html extension
"""

import http.server
import socketserver
import os
import urllib.parse
from pathlib import Path

class CleanURLHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=os.path.dirname(os.path.abspath(__file__)), **kwargs)
    
    def do_GET(self):
        # Parse the URL
        parsed_path = urllib.parse.urlparse(self.path)
        path = parsed_path.path.strip('/')
        
        # Handle root path
        if not path or path == 'index':
            self.serve_file('index.html')
            return
        
        # Handle common static files
        if path.endswith(('.css', '.js', '.png', '.jpg', '.jpeg', '.gif', '.ico', '.svg', '.webp', '.html')):
            self.serve_file(path)
            return
        
        # Handle clean URLs - try to find corresponding HTML file
        html_file = f"{path}.html"
        if os.path.exists(html_file):
            self.serve_file(html_file)
            return
        
        # Handle directories with index.html
        if os.path.isdir(path):
            index_file = os.path.join(path, 'index.html')
            if os.path.exists(index_file):
                self.serve_file(index_file)
                return
        
        # If nothing found, return 404
        self.send_response(404)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(b'''
<!DOCTYPE html>
<html>
<head>
    <title>404 - Page Not Found</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
        h1 { color: #333; }
        p { color: #666; }
        a { color: #007bff; }
    </style>
</head>
<body>
    <h1>404 - Page Not Found</h1>
    <p>The page you're looking for doesn't exist.</p>
    <p><a href="/">Go back to homepage</a></p>
</body>
</html>
        ''')
    
    def serve_file(self, filename):
        try:
            with open(filename, 'rb') as f:
                content = f.read()
                
            # Determine content type
            if filename.endswith('.html'):
                content_type = 'text/html; charset=utf-8'
            elif filename.endswith('.css'):
                content_type = 'text/css; charset=utf-8'
            elif filename.endswith('.js'):
                content_type = 'application/javascript; charset=utf-8'
            elif filename.endswith(('.png', '.jpg', '.jpeg', '.gif', '.webp')):
                content_type = 'image/' + filename.split('.')[-1]
            elif filename.endswith('.svg'):
                content_type = 'image/svg+xml'
            elif filename.endswith('.ico'):
                content_type = 'image/x-icon'
            else:
                content_type = 'application/octet-stream'
            
            self.send_response(200)
            self.send_header('Content-type', content_type)
            self.send_header('Content-length', str(len(content)))
            self.end_headers()
            self.wfile.write(content)
            
        except FileNotFoundError:
            self.send_response(404)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(b'<h1>File not found</h1>')
        except Exception as e:
            self.send_response(500)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            self.wfile.write(f'<h1>Server Error: {str(e)}</h1>'.encode())

if __name__ == "__main__":
    PORT = 9000
    
    print(f"Starting server with clean URL support on port {PORT}")
    print(f"Open http://localhost:{PORT} in your browser")
    print("Press Ctrl+C to stop the server")
    
    with socketserver.TCPServer(("", PORT), CleanURLHandler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nServer stopped")
