const navToggle = document.querySelector('.nav__toggle');
const navList = document.querySelector('.nav__list');

if (navToggle && navList) {
  navToggle.addEventListener('click', () => {
    const isOpen = navList.classList.toggle('is-open');
    navToggle.setAttribute('aria-expanded', String(isOpen));
  });
}

const templateSelect = document.querySelector('.template-select');
const templateCards = document.querySelectorAll('.template-card');
const templateModal = document.querySelector('.template-modal');
const templateModalClose = document.querySelector('.template-modal__close');
const templateModalPreview = document.querySelector('.template-modal__preview');
let templateIframe = null;

if (templateModalPreview) {
  templateIframe = document.createElement('iframe');
  templateModalPreview.appendChild(templateIframe);
}
const templateModalTitle = document.querySelector('.template-modal__title');

if (templateCards.length) {
  templateCards.forEach((card) => {
    const selectBtn = card.querySelector('.template-select-btn');
    const previewBtn = card.querySelector('.template-preview-btn');
    const templateName = card.getAttribute('data-template');
    const previewStyle = card.getAttribute('data-preview');
    const previewUrl = card.getAttribute('data-preview-url');

    if (selectBtn) {
      selectBtn.addEventListener('click', () => {
        // Show template selected message
        alert(`Template "${templateName}" selected! Contact us via WhatsApp to get started.`);
      });
    }

    if (previewBtn && templateModal && templateModalPreview && templateModalTitle) {
      previewBtn.addEventListener('click', () => {
        templateModalPreview.className = `template-modal__preview preview--${previewStyle || 'minimal'}`;
        templateModalTitle.textContent = templateName || 'Template preview';
        if (templateIframe) {
          if (previewUrl) {
            templateIframe.src = previewUrl;
          } else {
            templateIframe.removeAttribute('src');
          }
        }
        templateModal.hidden = false;
      });
    }
  });
}

if (templateModal && templateModalClose) {
  const closeModal = () => {
    if (templateIframe) {
      templateIframe.removeAttribute('src');
    }
    templateModal.hidden = true;
  };
  templateModalClose.addEventListener('click', closeModal);
  templateModal.addEventListener('click', (e) => {
    if (e.target === templateModal || e.target.classList.contains('template-modal__backdrop')) {
      closeModal();
    }
  });
}

