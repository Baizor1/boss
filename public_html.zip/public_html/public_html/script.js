const navToggle = document.querySelector('.nav__toggle');
const navList = document.querySelector('.nav__list');

if (navToggle && navList) {
  navToggle.addEventListener('click', () => {
    const isOpen = navList.classList.toggle('is-open');
    navToggle.setAttribute('aria-expanded', String(isOpen));
  });
}

const templateSelect = document.querySelector('.template-select');
const templateCards = document.querySelectorAll('.template-card');
const templateModal = document.querySelector('.template-modal');
const templateModalClose = document.querySelector('.template-modal__close');
const templateModalPreview = document.querySelector('.template-modal__preview');
let templateIframe = null;

if (templateModalPreview) {
  templateIframe = document.createElement('iframe');
  templateModalPreview.appendChild(templateIframe);
}
const templateModalTitle = document.querySelector('.template-modal__title');

if (templateCards.length) {
  templateCards.forEach((card) => {
    const selectBtn = card.querySelector('.template-select-btn');
    const previewBtn = card.querySelector('.template-preview-btn');
    const templateName = card.getAttribute('data-template');
    const previewStyle = card.getAttribute('data-preview');
    const previewUrl = card.getAttribute('data-preview-url');

    if (selectBtn) {
      selectBtn.addEventListener('click', () => {
        // Show template selected message
        alert(`Template "${templateName}" selected! Please fill out the contact form to get started.`);
      });
    }

    if (previewBtn && templateModal && templateModalPreview && templateModalTitle) {
      previewBtn.addEventListener('click', () => {
        templateModalPreview.className = `template-modal__preview preview--${previewStyle || 'minimal'}`;
        templateModalTitle.textContent = templateName || 'Template preview';
        if (templateIframe) {
          if (previewUrl) {
            templateIframe.src = previewUrl;
          } else {
            templateIframe.removeAttribute('src');
          }
        }
        templateModal.hidden = false;
      });
    }
  });
}

if (templateModal && templateModalClose) {
  const closeModal = () => {
    if (templateIframe) {
      templateIframe.removeAttribute('src');
    }
    templateModal.hidden = true;
  };
  templateModalClose.addEventListener('click', closeModal);
  templateModal.addEventListener('click', (e) => {
    if (e.target === templateModal || e.target.classList.contains('template-modal__backdrop')) {
      closeModal();
    }
  });
}

// Contact Form Handling
const contactForm = document.getElementById('contactForm');
const formStatus = document.getElementById('formStatus');
const charCount = document.getElementById('charCount');
const messageTextarea = document.getElementById('message');

if (messageTextarea && charCount) {
  messageTextarea.addEventListener('input', (e) => {
    charCount.textContent = e.target.value.length;
  });
}

if (contactForm) {
  contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const submitBtn = contactForm.querySelector('#submitBtn');
    const originalBtnText = submitBtn.textContent;

    // Simple validation
    if (!contactForm.checkValidity()) {
      contactForm.reportValidity();
      return;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = 'Sending...';
    formStatus.textContent = '';
    formStatus.className = 'form-status show'; // Add show class immediately

    const formData = new FormData(contactForm);
    const data = Object.fromEntries(formData.entries());

    try {
      // Using Formspree as the backend service
      // Replace 'mqakevoz' with your real Formspree ID
      const response = await fetch('https://formspree.io/f/mkowqpqg', {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        formStatus.textContent = 'Message sent successfully! We will get back to you soon.';
        formStatus.className = 'form-status success show';
        contactForm.reset();
        if (charCount) charCount.textContent = '0';
      } else {
        const result = await response.json();
        console.error('Formspree error:', result);
        if (result.errors) {
          formStatus.textContent = result.errors.map(error => error.message).join(', ');
        } else {
          formStatus.textContent = 'Oops! There was a problem submitting your form.';
        }
        formStatus.className = 'form-status error show';
      }
    } catch (error) {
      console.error('Submission error:', error);
      formStatus.textContent = 'Oops! There was a problem submitting your form.';
      formStatus.className = 'form-status error show';
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = originalBtnText;
    }
  });


  const resetBtn = document.getElementById('resetBtn');
  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      contactForm.reset();
      formStatus.textContent = '';
      formStatus.className = 'form-status';
      if (charCount) charCount.textContent = '0';
    });
  }
}
